cmake_minimum_required(VERSION 3.22)

#
# 底盘工程（CHASSIS）：STM32F103C8T6 控制 6 轮 + 2 前舵机
#

# Setup compiler settings
set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_C_EXTENSIONS ON)

# Define the build type
if(NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE "Debug")
endif()

# Set the project name
set(CMAKE_PROJECT_NAME CHASSIS)

# Enable compile command to ease indexing with e.g. clangd
set(CMAKE_EXPORT_COMPILE_COMMANDS TRUE)

# Core project settings
project(${CMAKE_PROJECT_NAME})
message("Build type: " ${CMAKE_BUILD_TYPE})

# Enable CMake support for ASM and C languages
enable_language(C ASM)

# Create an executable object type
add_executable(${CMAKE_PROJECT_NAME})

# Add STM32CubeMX generated sources
add_subdirectory(cmake/stm32cubemx)

# Link directories setup
target_link_directories(${CMAKE_PROJECT_NAME} PRIVATE
    # Add user defined library search paths
)

# Add sources to executable
target_sources(${CMAKE_PROJECT_NAME} PRIVATE
    # 底盘驱动 / 动作层 / 串口帧解析（整车控制）
    Core/Src/chassis.c
    Core/Src/chassis_control.c
    Core/Src/chassis_uart.c
    Core/Src/retarget.c
)

# Add include paths
target_include_directories(${CMAKE_PROJECT_NAME} PRIVATE
    # Add user defined include paths
)

# Add project symbols (macros)
target_compile_definitions(${CMAKE_PROJECT_NAME} PRIVATE
    # Add user defined symbols
)

# Remove wrong libob.a library dependency when using cpp files
list(REMOVE_ITEM CMAKE_C_IMPLICIT_LINK_LIBRARIES ob)

# Add linked libraries
target_link_libraries(${CMAKE_PROJECT_NAME}
    stm32cubemx
    m               # 若调试打印用到 sinf/cosf/fabsf 等数学函数

    # Add user defined libraries
)

# 让 printf 支持 %f 浮点格式（newlib-nano 默认砍掉浮点打印）。
# 底盘调试若只打印整数可去掉，但保留无害。
target_link_options(${CMAKE_PROJECT_NAME} PRIVATE -Wl,-u,_printf_float)
