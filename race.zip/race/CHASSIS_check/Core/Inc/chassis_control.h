#ifndef __CHASSIS_CONTROL_H
#define __CHASSIS_CONTROL_H

#include <stdint.h>

#define Left     0
#define Forward  1
#define Right    2
#define Ahead    3
#define Back     4
#define Stop     5

extern int Turning_Direction;
extern int Moving_Direction;

void Turn_Stright(void);
void Turn_Right(int x);
void Turn_Left(int x);

void Move_Stright(int y);
void Moving_Left(int y);
void Moving_Right(int y);

void Move(int x, int y);

#endif
