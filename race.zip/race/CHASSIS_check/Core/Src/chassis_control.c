#include "chassis_control.h"
#include "chassis.h"

#define Left 0
#define Forward 1
#define Right 2

#define Ahead 3
#define Back 4
#define Stop 5

int Turning_Direction = Forward;
int Moving_Direction = Stop;

void Turn_Stright()
{
    servo_L(0);
    servo_R(0);
}

void Turn_Right(int x)
{
    if (x > 202)
    {
        servo_L(-45);
        servo_R(-19);
    }
    else if (x > 148)
    {
        servo_L(-30);
        servo_R(-25);
    }

}

void Turn_Left(int x)
{
    if (x < 54)
    {
        servo_L(19);
        servo_R(45);
    }
    else if (x < 108)
    {
        servo_L(25);
        servo_R(30);
    }

}

// 速度算出来可能超过 100，后面会限幅
void Move_Stright(int y)
{
    int speed_rate;

    if (y - 127 > 20 && y <= 255)
    {
        speed_rate = (y - 127) * 100 / 107;
        Motor_All(speed_rate);
        Moving_Direction = Ahead;
    }

    else if (y - 127 < -20)
    {
        speed_rate = (y - 127) * 100 / 107;
        Motor_All(speed_rate);
        Moving_Direction = Back;
    }

    else
    {
        Motor_Brake();
        Moving_Direction = Stop;
    }
}

// 转弯时内侧轮速减半
void Moving_Left(int y)
{
    int speed_rate;

    if (y - 127 > 20 && y <= 255)
    {
        speed_rate = (y - 127) * 100 / 107;
        Motor_LeftSide(speed_rate / 2);
        Motor_RightSide(speed_rate);
        Moving_Direction = Ahead;
    }

    else if (y - 127 < -20)
    {
        speed_rate = (y - 127) * 100 / 107;
        Motor_LeftSide(speed_rate / 2);
        Motor_RightSide(speed_rate);
        Moving_Direction = Back;
    }

    else
    {
        Motor_Brake();
        Moving_Direction = Stop;
    }
}

void Moving_Right(int y)
{
    int speed_rate;

    if (y - 127 > 20 && y <= 255)
    {
        speed_rate = (y - 127) * 100 / 107;
        Motor_LeftSide(speed_rate);
        Motor_RightSide(speed_rate / 2);
        Moving_Direction = Ahead;
    }

    else if (y - 127 < -20)
    {
        speed_rate = (y - 127) * 100 / 107;
        Motor_LeftSide(speed_rate);
        Motor_RightSide(speed_rate / 2);
        Moving_Direction = Back;
    }

    else
    {
        Motor_Brake();
        Moving_Direction = Stop;
    }
}

// 摇杆中位附近设死区，避免轻微抖动引起动作
void Move(int x, int y)
{

    if (x > 148)      Turning_Direction = Right;
    else if (x < 108) Turning_Direction = Left;
    else              Turning_Direction = Forward;

    if (y > 147)      Moving_Direction = Ahead;
    else if (y < 107) Moving_Direction = Back;
    else              Moving_Direction = Stop;

    if (Moving_Direction == Ahead || Moving_Direction == Back){
        if (Turning_Direction == Left){
            Turn_Left(x);
            Moving_Left(y);
        }
        else if (Turning_Direction == Right){
            Turn_Right(x);
            Moving_Right(y);
        }else {
            Turn_Stright();
            Move_Stright(y);
        }
    }

    if (Moving_Direction == Stop){
        Motor_Brake();
        if (Turning_Direction == Left){
            Turn_Left(x);
        }
        else if (Turning_Direction == Right){
            Turn_Right(x);
        }else {
            Turn_Stright();
        }
    }
}
