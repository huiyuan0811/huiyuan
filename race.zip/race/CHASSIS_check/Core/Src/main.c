/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : 底盘整车主程序（STM32F103C8T6）
  *                  接收主控板经 USART3 发来的控制帧，驱动 6 轮 + 2 前舵机。
  ******************************************************************************
  */
/* USER CODE END Header */
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "chassis.h"
#include "chassis_control.h"
#include "chassis_uart.h"
#include <stdio.h>

uint8_t g_uart3_rx_byte = 0;

/* Private variables ---------------------------------------------------------*/
volatile uint8_t chassis_tick_flag = 0;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

void SystemClock_Config(void);
void Error_Handler(void);

int main(void)
{
  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_USART3_UART_Init();

  // 状态行不换行，需要关掉缓冲才会输出
  setvbuf(stdout, NULL, _IONBF, 0);

  /* USER CODE BEGIN 2 */
  // 上电先刹车回正，再开串口接收
  Motor_Init();
  ChassisUart_Init();
  Turn_Stright();
  Motor_Brake();

  if (HAL_UART_Receive_IT(&huart3, &g_uart3_rx_byte, 1) != HAL_OK)
  {
    Error_Handler();
  }

  printf("CHASSIS READY @USART3 115200 | recv frame: AA 55 LX LY SUM\r\n");
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    int x = 128, y = 128;
    uint32_t now = HAL_GetTick();

    // 超时后刹车，避免车辆持续行进
    if (ChassisUart_IsTimeout(now))
    {

      Motor_Brake();
      Turn_Stright();
    }
    else if (ChassisUart_GetLatest(&x, &y))
    {
      Move(x, y);
    }

    HAL_Delay(10);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/**
  * @brief  USART3 接收完成回调：把收到的字节喂给帧解析状态机，并重新武装接收。
  * @note   单字节中断模式；每次收到 1 字节进入一次，必须再次调用 Receive_IT。
  */
// 每收完一个字节需要重新开启接收，否则只会收到首字节
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART3)
  {
    ChassisUart_FeedByte(g_uart3_rx_byte, HAL_GetTick());
    HAL_UART_Receive_IT(&huart3, &g_uart3_rx_byte, 1);
  }
}

/**
  * @brief  UART 接收错误回调：清错误标志并重新武装接收。
  * @note   若发生溢出(ORE)/帧错误，HAL 的 RX 中断会停止、且不再自动重装，
  *         底盘将永远收不到新帧（最终被看门狗刹停）。这里兜底恢复。
  */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART3)
  {
    __HAL_UART_CLEAR_OREFLAG(&huart3);
    HAL_UART_Receive_IT(&huart3, &g_uart3_rx_byte, 1);
  }
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}
/* USER CODE END 4 */

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{

}
#endif
