#include "chassis.h"
#include "sim_main.h"
#include "sim_stm32f1xx_hal_tim.h"
#include <stdint.h>

extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;

void Motor_Init(void)
{

    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
    __HAL_TIM_MOE_ENABLE(&htim1);

    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);

    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_4);
}

typedef struct{
    TIM_HandleTypeDef *htim;
    uint32_t channel1;
    uint32_t channel2;
}Motor_TypeDef ;

Motor_TypeDef Motor[6] =
{
    {&htim2, TIM_CHANNEL_1, TIM_CHANNEL_2},
    {&htim2, TIM_CHANNEL_3, TIM_CHANNEL_4},
    {&htim3, TIM_CHANNEL_1, TIM_CHANNEL_2},
    {&htim3, TIM_CHANNEL_3, TIM_CHANNEL_4},
    {&htim4, TIM_CHANNEL_1, TIM_CHANNEL_2},
    {&htim4, TIM_CHANNEL_3, TIM_CHANNEL_4}
};

void Motor_Control(char Motor_ID, int speed)
{
    if (Motor_ID < 'A' || Motor_ID > 'F') return;

    if (speed > 100) speed = 100;
    if (speed < -100) speed = -100;

    uint8_t ID = Motor_ID - 'A';

    TIM_HandleTypeDef *htim = Motor[ID].htim;

    uint32_t ch1 = Motor[ID].channel1;
    uint32_t ch2 = Motor[ID].channel2;

    uint32_t ARR = __HAL_TIM_GET_AUTORELOAD(htim);

    uint32_t CCR = (speed >= 0 ? (uint32_t)speed : (uint32_t)(-speed)) * (ARR + 1) / 100;

    if (speed > 0)
    {
        __HAL_TIM_SET_COMPARE(htim, ch1, CCR);
        __HAL_TIM_SET_COMPARE(htim, ch2, 0);
    }

    else if (speed < 0)
    {
        __HAL_TIM_SET_COMPARE(htim, ch1, 0);
        __HAL_TIM_SET_COMPARE(htim, ch2, CCR);
    }

    else
    {
        __HAL_TIM_SET_COMPARE(htim, ch1, ARR);
        __HAL_TIM_SET_COMPARE(htim, ch2, ARR);
    }
}

void Motor_LeftSide(int speed)
{
    Motor_Control('A', speed);
    Motor_Control('C', speed);
    Motor_Control('E', speed);
}

void Motor_RightSide(int speed)
{
    Motor_Control('B', -speed);
    Motor_Control('D', -speed);
    Motor_Control('F', -speed);
}

void Motor_All(int speed)
{
    Motor_LeftSide(speed);
    Motor_RightSide(speed);
}

void Motor_Brake()
{
    Motor_LeftSide(0);
    Motor_RightSide(0);
}

void servo_L(int angle)
{
    int real_angle;

    if (angle > -90 && angle < 90)
        real_angle = angle + 90;
    else
        real_angle = 90;

    uint32_t CCR = 500 + real_angle * 2000 / 180;

    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, CCR);
}

void servo_R(int angle)
{
    int real_angle;

    if (angle > -90 && angle < 90)
        real_angle = angle + 90;
    else
        real_angle = 90;

    uint32_t CCR = 500 + real_angle * 2000 / 180;

    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, CCR);
}
