#ifndef __CHASSIS_H
#define __CHASSIS_H

#include "sim_main.h"
#include <stdint.h>

extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;

#define CHASSIS_SERVO_MIN_ANGLE  -89
#define CHASSIS_SERVO_MAX_ANGLE   89

#define CHASSIS_MOTOR_MIN_SPEED  -100
#define CHASSIS_MOTOR_MAX_SPEED   100

void Motor_Init(void);

void Motor_Control(char Motor_ID, int speed);

void Motor_LeftSide(int speed);

void Motor_RightSide(int speed);

void Motor_All(int speed);

void Motor_Brake(void);

void servo_L(int angle);

void servo_R(int angle);

#endif
