#include "chassis_uart.h"

static ChassisUart_State s_state = {128, 128, 0, 0};
static uint8_t s_idx  = 0;
static uint8_t s_buf[5];

uint8_t ChassisUart_ComputeChecksum(uint8_t lx, uint8_t ly)
{
    return (uint8_t)((CHASSIS_FRAME_H0 + CHASSIS_FRAME_H1 + lx + ly) & 0xFF);
}

void ChassisUart_Init(void)
{
    s_state.lx = 128; s_state.ly = 128; s_state.valid = 0; s_state.last_tick = 0;
    s_idx = 0;
}

void ChassisUart_FeedByte(uint8_t b, uint32_t tick_ms)
{
    switch (s_idx)
    {
      case 0:
        if (b == CHASSIS_FRAME_H0) { s_buf[0] = b; s_idx = 1; }
        else s_idx = 0;
        break;

      case 1:
        if (b == CHASSIS_FRAME_H1) { s_buf[1] = b; s_idx = 2; }
        else { s_idx = 0;
               if (b == CHASSIS_FRAME_H0) { s_buf[0] = b; s_idx = 1; } }
        break;

      case 2:
        s_buf[2] = b; s_idx = 3;
        break;

      case 3:
        s_buf[3] = b; s_idx = 4;
        break;

      case 4:
        s_buf[4] = b;
        if (b == ChassisUart_ComputeChecksum(s_buf[2], s_buf[3]))
        {
            s_state.lx = s_buf[2];
            s_state.ly = s_buf[3];
            s_state.valid = 1;
            s_state.last_tick = tick_ms;
        }
        s_idx = 0;
        break;

      default:
        s_idx = 0;
        break;
    }
}

uint8_t ChassisUart_GetLatest(int *x, int *y)
{
    if (!s_state.valid) return 0;
    *x = (int)s_state.lx;
    int ly = (int)s_state.ly;
    *y = CHASSIS_INVERT_Y ? (255 - ly) : ly;
    return 1;
}

uint8_t ChassisUart_IsTimeout(uint32_t tick_ms)
{
    if (!s_state.valid) return 1;
    return ((tick_ms - s_state.last_tick) >= CHASSIS_TIMEOUT_MS) ? 1 : 0;
}
