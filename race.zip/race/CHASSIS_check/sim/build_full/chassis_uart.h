#ifndef __CHASSIS_UART_H
#define __CHASSIS_UART_H

#include <stdint.h>

#define CHASSIS_FRAME_H0     0xAA
#define CHASSIS_FRAME_H1     0x55
#define CHASSIS_TIMEOUT_MS   400

#define CHASSIS_INVERT_Y     1

typedef struct {
    uint8_t  lx;
    uint8_t  ly;
    uint8_t  valid;
    uint32_t last_tick;
} ChassisUart_State;

uint8_t ChassisUart_ComputeChecksum(uint8_t lx, uint8_t ly);

void ChassisUart_Init(void);

void ChassisUart_FeedByte(uint8_t b, uint32_t tick_ms);

uint8_t ChassisUart_GetLatest(int *x, int *y);

uint8_t ChassisUart_IsTimeout(uint32_t tick_ms);

#endif
