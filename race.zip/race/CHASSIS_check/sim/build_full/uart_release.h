/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    uart_release.h
  * @brief   接底盘 MCU 的串口驱动（底层 USART2，PA2=TX / PA3=RX）
  *
  *  用途：把本机“左摇杆(预留)”的 LX / LY 原始值，通过 USART2 发给另一块
  *        单片机（底盘 MCU），由它去驱动底盘。本驱动只管“按协议发帧”，
  *        不关心底盘怎么用这两个值——所以叫 release（释放/交给对方）。
  *
  *  引脚：PA2 = USART2_TX（连底盘 MCU 的 RX）
  *        PA3 = USART2_RX（连底盘 MCU 的 TX，本驱动暂未解析，仅留着）
  *        电平 3.3V（F103 非 5V 容忍，与 5V MCU 互联需电平转换）
  *  波特：默认 115200（在 usart.c 的 MX_USART2_UART_Init 里改 BaudRate）
  *
  *  通信协议（每帧 5 字节，建议每 50ms 发一帧，约 20Hz）：
  *    [0] 0xAA       帧头1（同步字节，固定）
  *    [1] 0x55       帧头2（同步字节，固定）
  *    [2] LX   0..255 左摇杆 X（128=居中；具体含义由底盘 MCU 约定）
  *    [3] LY   0..255 左摇杆 Y（128=居中）
  *    [4] SUM         校验和 = (0xAA + 0x55 + LX + LY) & 0xFF
  *  底盘 MCU 解析：先同步到 0xAA 0x55，再收 LX、LY，最后校验 SUM，
  *     SUM 不符则丢弃本帧（防误触发）。
  ******************************************************************************
  */
/* USER CODE END Header */
#ifndef __UART_RELEASE_H
#define __UART_RELEASE_H

#include "sim_main.h"

#ifdef __cplusplus
extern "C" {
#endif

/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

#define UART_RELEASE_HDR0       0xAA
#define UART_RELEASE_HDR1       0x55
#define UART_RELEASE_FRAME_LEN  ((uint8_t)5)
#define UART_RELEASE_NEUTRAL    ((uint8_t)128)

/* USER CODE BEGIN Private defines */
/* USER CODE END Private defines */

void UART_RELEASE_Init(void);

HAL_StatusTypeDef UART_RELEASE_SendJoystick(uint8_t lx, uint8_t ly);

HAL_StatusTypeDef UART_RELEASE_SendNeutral(void);

HAL_StatusTypeDef UART_RELEASE_SendJoystickIfChanged(uint8_t lx, uint8_t ly);

/* USER CODE BEGIN Prototypes */
/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif
