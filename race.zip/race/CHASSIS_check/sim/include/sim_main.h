#ifndef SIM_MAIN_H
#define SIM_MAIN_H

#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint32_t ARR;
    uint32_t CCR1, CCR2, CCR3, CCR4;
    uint32_t BDTR;
} TIM_TypeDef;

typedef struct {
    void *Instance;
} UART_HandleTypeDef;

typedef struct {
    TIM_TypeDef *Instance;
} TIM_HandleTypeDef;

typedef enum {
    HAL_OK      = 0x00U,
    HAL_ERROR   = 0x01U,
    HAL_BUSY    = 0x02U,
    HAL_TIMEOUT = 0x03U
} HAL_StatusTypeDef;

#define TIM_CHANNEL_1   0x00000000U
#define TIM_CHANNEL_2   0x00000004U
#define TIM_CHANNEL_3   0x00000008U
#define TIM_CHANNEL_4   0x0000000CU

#define __HAL_TIM_GET_AUTORELOAD(h)        ((h)->Instance->ARR)
#define __HAL_TIM_MOE_ENABLE(h)            ((h)->Instance->BDTR |= 0x8000U)
#define __HAL_TIM_SET_COMPARE(h, ch, v)    sim_set_compare((h), (ch), (v))

HAL_StatusTypeDef HAL_TIM_PWM_Start(TIM_HandleTypeDef *htim, uint32_t Channel);

#define SIM_NCAP 128
typedef struct { TIM_TypeDef *inst; uint32_t ch; uint32_t val; } SimCap;
extern SimCap  g_cap[SIM_NCAP];
extern int     g_ncap;
void sim_set_compare(TIM_HandleTypeDef *h, uint32_t ch, uint32_t v);

extern TIM_HandleTypeDef htim1, htim2, htim3, htim4;
extern UART_HandleTypeDef huart2;

extern uint8_t g_tx_buf[16];
extern int     g_tx_len;
HAL_StatusTypeDef HAL_UART_Transmit(UART_HandleTypeDef *huart, uint8_t *pData,
                                    uint16_t Size, uint32_t Timeout);

#endif
