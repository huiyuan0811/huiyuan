#ifndef SIM_USART_H
#define SIM_USART_H
#include "sim_main.h"

extern UART_HandleTypeDef huart2;
#endif
