#ifndef STM32F1XX_HAL_H_MOTOR_STUB
#define STM32F1XX_HAL_H_MOTOR_STUB

#include <stdint.h>

typedef enum {
  HAL_OK      = 0x00U,
  HAL_ERROR   = 0x01U,
  HAL_BUSY    = 0x02U,
  HAL_TIMEOUT = 0x03U
} HAL_StatusTypeDef;

typedef enum {
  GPIO_PIN_RESET = 0,
  GPIO_PIN_SET   = 1
} GPIO_PinState;

#define GPIO_PIN_0  ((uint16_t)0x0001)
#define GPIO_PIN_1  ((uint16_t)0x0002)
#define GPIO_PIN_2  ((uint16_t)0x0004)
#define GPIO_PIN_3  ((uint16_t)0x0008)
#define GPIO_PIN_4  ((uint16_t)0x0010)
#define GPIO_PIN_5  ((uint16_t)0x0020)
#define GPIO_PIN_6  ((uint16_t)0x0040)
#define GPIO_PIN_7  ((uint16_t)0x0080)
#define GPIO_PIN_8  ((uint16_t)0x0100)
#define GPIO_PIN_9  ((uint16_t)0x0200)
#define GPIO_PIN_10 ((uint16_t)0x0400)
#define GPIO_PIN_11 ((uint16_t)0x0800)
#define GPIO_PIN_12 ((uint16_t)0x1000)
#define GPIO_PIN_13 ((uint16_t)0x2000)
#define GPIO_PIN_14 ((uint16_t)0x4000)
#define GPIO_PIN_15 ((uint16_t)0x8000)

typedef struct { uint32_t dummy; } GPIO_TypeDef;
#define GPIOA ((GPIO_TypeDef *)0x1000)
#define GPIOB ((GPIO_TypeDef *)0x1001)
#define GPIOC ((GPIO_TypeDef *)0x1002)

typedef struct {
  uint32_t Pin;
  uint32_t Mode;
  uint32_t Pull;
  uint32_t Speed;
} GPIO_InitTypeDef;

#define GPIO_MODE_INPUT             0x00000000U
#define GPIO_MODE_OUTPUT_PP         0x00000001U
#define GPIO_MODE_AF_PP             0x00000002U
#define GPIO_NOPULL                 0x00000000U
#define GPIO_PULLUP                 0x00000001U
#define GPIO_SPEED_FREQ_LOW         0x00000001U
#define GPIO_SPEED_FREQ_HIGH        0x00000002U

typedef uint32_t TIM_TypeDef;
#define TIM1 ((TIM_TypeDef *)0x2001U)
#define TIM2 ((TIM_TypeDef *)0x2002U)

typedef struct {
  uint32_t Prescaler;
  uint32_t Period;
  uint32_t CounterMode;
  uint32_t ClockDivision;
  uint32_t RepetitionCounter;
  uint32_t AutoReloadPreload;
} TIM_Base_InitTypeDef;

typedef struct {
  TIM_TypeDef      *Instance;
  TIM_Base_InitTypeDef Init;
} TIM_HandleTypeDef;

#define TIM_CHANNEL_1 ((uint32_t)0x00000000U)
#define TIM_CHANNEL_2 ((uint32_t)0x00000004U)
#define TIM_CHANNEL_3 ((uint32_t)0x00000008U)
#define TIM_CHANNEL_4 ((uint32_t)0x0000000CU)
#define TIM_CHANNEL_ALL ((uint32_t)0x00000018U)

typedef struct {
  uint32_t OCMode;
  uint32_t Pulse;
  uint32_t OCPolarity;
  uint32_t OCFastMode;
} TIM_OC_InitTypeDef;

typedef struct {
  uint32_t EncoderMode;
  uint32_t IC1Polarity;
  uint32_t IC1Selection;
  uint32_t IC1Prescaler;
  uint32_t IC1Filter;
  uint32_t IC2Polarity;
  uint32_t IC2Selection;
  uint32_t IC2Prescaler;
  uint32_t IC2Filter;
} TIM_Encoder_InitTypeDef;

#define TIM_COUNTERMODE_UP                 0x00000000U
#define TIM_CLOCKDIVISION_DIV1             0x00000000U
#define TIM_AUTORELOAD_PRELOAD_DISABLE     0x00000000U
#define TIM_OCMODE_PWM1                    0x00000006U
#define TIM_OCPOLARITY_HIGH                0x00000000U
#define TIM_OCFAST_DISABLE                 0x00000000U
#define TIM_ENCODERMODE_TI12               0x00000003U
#define TIM_ICPOLARITY_RISING              0x00000000U
#define TIM_ICSELECTION_DIRECTTI           0x00000001U
#define TIM_ICPSC_DIV1                     0x00000000U

extern uint16_t g_pwm;
extern int16_t  g_enc_cnt;
extern uint8_t  g_in1;
extern uint8_t  g_in2;

#define __HAL_TIM_SET_COMPARE(h, c, v) do { g_pwm = (uint16_t)(v); } while (0)
#define __HAL_TIM_GET_COUNTER(h)       ((uint32_t)g_enc_cnt)
#define __HAL_TIM_MOE_ENABLE(h)         do { } while (0)
#define __HAL_RCC_TIM1_CLK_ENABLE()     do { } while (0)
#define __HAL_RCC_TIM2_CLK_ENABLE()     do { } while (0)
#define __HAL_RCC_GPIOA_CLK_ENABLE()    do { } while (0)
#define __HAL_RCC_GPIOB_CLK_ENABLE()    do { } while (0)

#define HAL_TIM_PWM_Init(h)          ((void)0)
#define HAL_TIM_PWM_ConfigChannel(h,o,c) ((void)0)
#define HAL_TIM_PWM_Start(h,c)        ((void)0)
#define HAL_TIM_Encoder_Init(h,e)     ((void)0)
#define HAL_TIM_Encoder_Start(h,c)    ((void)0)

extern uint32_t SystemCoreClock;

HAL_StatusTypeDef HAL_GPIO_WritePin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin, GPIO_PinState PinState);
void              HAL_GPIO_Init(GPIO_TypeDef *GPIOx, GPIO_InitTypeDef *GPIO_Init);
GPIO_PinState     HAL_GPIO_ReadPin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void              HAL_Delay(uint32_t Delay);

#endif
