#ifndef STM32F1XX_HAL_H_UART_STUB
#define STM32F1XX_HAL_H_UART_STUB

#include <stdint.h>

typedef enum {
  HAL_OK      = 0x00U,
  HAL_ERROR   = 0x01U,
  HAL_BUSY    = 0x02U,
  HAL_TIMEOUT = 0x03U
} HAL_StatusTypeDef;

typedef struct {
  void    *Instance;
  uint32_t dummy;
} UART_HandleTypeDef;

#define UART_WORDLENGTH_8B    0x00000000U
#define UART_STOPBITS_1       0x00000000U
#define UART_PARITY_NONE      0x00000000U
#define UART_MODE_TX_RX       0x00000000U
#define UART_HWCONTROL_NONE   0x00000000U
#define UART_OVERSAMPLING_16  0x00000000U

extern uint8_t  g_tx[16];
extern uint16_t g_tx_len;
extern uint16_t g_tx_count;

HAL_StatusTypeDef HAL_UART_Transmit(UART_HandleTypeDef *huart,
                                    uint8_t *pData,
                                    uint16_t Size,
                                    uint32_t Timeout);

extern UART_HandleTypeDef huart2;

#endif
