#include "sim_main.h"
#include "chassis.h"
#include "chassis_control.h"
#include "chassis_uart.h"
#include "uart_release.h"

#include <stdio.h>
#include <string.h>

TIM_TypeDef t1, t2, t3, t4;
TIM_HandleTypeDef htim1 = {&t1}, htim2 = {&t2}, htim3 = {&t3}, htim4 = {&t4};
UART_HandleTypeDef huart2;

SimCap  g_cap[SIM_NCAP];
int     g_ncap = 0;
uint8_t g_tx_buf[16];
int     g_tx_len = 0;

void sim_set_compare(TIM_HandleTypeDef *h, uint32_t ch, uint32_t v) {
    if (g_ncap < SIM_NCAP) {
        g_cap[g_ncap].inst = h->Instance;
        g_cap[g_ncap].ch   = ch;
        g_cap[g_ncap].val  = v;
        g_ncap++;
    }
}
HAL_StatusTypeDef HAL_TIM_PWM_Start(TIM_HandleTypeDef *htim, uint32_t Channel) {
    (void)htim; (void)Channel; return HAL_OK;
}
HAL_StatusTypeDef HAL_UART_Transmit(UART_HandleTypeDef *huart, uint8_t *pData,
                                    uint16_t Size, uint32_t Timeout) {
    (void)huart; (void)Timeout;
    g_tx_len = (Size > 16) ? 16 : (int)Size;
    memcpy(g_tx_buf, pData, (size_t)g_tx_len);
    return HAL_OK;
}

static void clear_cap(void) { g_ncap = 0; }
static uint32_t read_ccr(TIM_TypeDef *inst, uint32_t ch) {
    for (int i = 0; i < g_ncap; i++)
        if (g_cap[i].inst == inst && g_cap[i].ch == ch) return g_cap[i].val;
    return 0xFFFFFFFFu;
}

static uint32_t servo_ccr(int angle) {
    int a = (angle > -90 && angle < 90) ? angle + 90 : 90;
    return (uint32_t)(500 + a * 2000 / 180);
}

static uint32_t motor_ccr(int speed) {
    if (speed > 100) speed = 100;
    if (speed < -100) speed = -100;
    int s = speed >= 0 ? speed : -speed;
    return (uint32_t)s * (999 + 1) / 100;
}

static int g_pass = 0, g_fail = 0;
static void check_i(const char *name, int64_t got, int64_t exp) {
    if (got == exp) { g_pass++; printf("  PASS: %s = %lld\n", name, (long long)got); }
    else { g_fail++; printf("  FAIL: %s = %lld (期望 %lld)\n", name, (long long)got, (long long)exp); }
}

// 把真实的收发代码放一起测，检查两端协议是否一致
int main(void) {

    t1.ARR = 19999; t2.ARR = 999; t3.ARR = 999; t4.ARR = 999;
    Motor_Init();

    printf("===== 整车控制全链路仿真 =====\n");

    printf("[A] 中立 lx=128 ly=128 (预期: 刹车 + 舵机中位)\n");
    clear_cap(); ChassisUart_Init();
    ChassisUart_FeedByte(0xAA,0); ChassisUart_FeedByte(0x55,0);
    ChassisUart_FeedByte(128,0);  ChassisUart_FeedByte(128,0);
    ChassisUart_FeedByte((uint8_t)((0xAA+0x55+128+128)&0xFF),0);
    {
        int x=0,y=0; ChassisUart_GetLatest(&x,&y);
        clear_cap(); Move(x, y);
        check_i("servo_L_CCR", read_ccr(&t1, TIM_CHANNEL_1), servo_ccr(0));
        check_i("servo_R_CCR", read_ccr(&t1, TIM_CHANNEL_2), servo_ccr(0));
        check_i("电机A ch1(应=ARR刹车)", read_ccr(&t2, TIM_CHANNEL_1), 999);
        check_i("电机A ch2(应=ARR刹车)", read_ccr(&t2, TIM_CHANNEL_2), 999);
    }

    printf("[B] 上推到底 lx=128 ly=0 (预期: y翻转=255 -> 全速前进)\n");
    clear_cap(); ChassisUart_Init();
    ChassisUart_FeedByte(0xAA,0); ChassisUart_FeedByte(0x55,0);
    ChassisUart_FeedByte(128,0);  ChassisUart_FeedByte(0,0);
    ChassisUart_FeedByte((uint8_t)((0xAA+0x55+128+0)&0xFF),0);
    {
        int x=0,y=0; ChassisUart_GetLatest(&x,&y);
        check_i("解码 y(应=255)", y, 255);
        clear_cap(); Move(x, y);
        check_i("电机A ch1(前进满)", read_ccr(&t2, TIM_CHANNEL_1), motor_ccr(100));
        check_i("电机A ch2(应为0)", read_ccr(&t2, TIM_CHANNEL_2), 0);
    }

    printf("[C] 下推到底 lx=128 ly=255 (预期: y=0 -> 全速后退)\n");
    clear_cap(); ChassisUart_Init();
    ChassisUart_FeedByte(0xAA,0); ChassisUart_FeedByte(0x55,0);
    ChassisUart_FeedByte(128,0);  ChassisUart_FeedByte(255,0);
    ChassisUart_FeedByte((uint8_t)((0xAA+0x55+128+255)&0xFF),0);
    {
        int x=0,y=0; ChassisUart_GetLatest(&x,&y);
        check_i("解码 y(应=0)", y, 0);
        clear_cap(); Move(x, y);
        check_i("电机A ch1(应为0)", read_ccr(&t2, TIM_CHANNEL_1), 0);
        check_i("电机A ch2(后退满)", read_ccr(&t2, TIM_CHANNEL_2), motor_ccr(100));
    }

    printf("[D] 左推到底 lx=0 ly=128 (预期: 左转大角 + 刹车)\n");
    clear_cap(); ChassisUart_Init();
    ChassisUart_FeedByte(0xAA,0); ChassisUart_FeedByte(0x55,0);
    ChassisUart_FeedByte(0,0);    ChassisUart_FeedByte(128,0);
    ChassisUart_FeedByte((uint8_t)((0xAA+0x55+0+128)&0xFF),0);
    {
        int x=0,y=0; ChassisUart_GetLatest(&x,&y);
        clear_cap(); Move(x, y);
        check_i("servo_L_CCR(左转大角=19)", read_ccr(&t1, TIM_CHANNEL_1), servo_ccr(19));
        check_i("servo_R_CCR(左转大角=45)", read_ccr(&t1, TIM_CHANNEL_2), servo_ccr(45));
        check_i("电机A ch1(刹车)", read_ccr(&t2, TIM_CHANNEL_1), 999);
    }

    printf("[E] 右推到底 lx=255 ly=128 (预期: 右转大角 + 刹车)\n");
    clear_cap(); ChassisUart_Init();
    ChassisUart_FeedByte(0xAA,0); ChassisUart_FeedByte(0x55,0);
    ChassisUart_FeedByte(255,0);  ChassisUart_FeedByte(128,0);
    ChassisUart_FeedByte((uint8_t)((0xAA+0x55+255+128)&0xFF),0);
    {
        int x=0,y=0; ChassisUart_GetLatest(&x,&y);
        clear_cap(); Move(x, y);
        check_i("servo_L_CCR(右转大角=-45)", read_ccr(&t1, TIM_CHANNEL_1), servo_ccr(-45));
        check_i("servo_R_CCR(右转大角=-19)", read_ccr(&t1, TIM_CHANNEL_2), servo_ccr(-19));
    }

    printf("[F] 前进+右转 lx=200 ly=50 (预期: 右小角 + 左快(72)右慢(36))\n");
    clear_cap(); ChassisUart_Init();
    ChassisUart_FeedByte(0xAA,0); ChassisUart_FeedByte(0x55,0);
    ChassisUart_FeedByte(200,0);  ChassisUart_FeedByte(50,0);
    ChassisUart_FeedByte((uint8_t)((0xAA+0x55+200+50)&0xFF),0);
    {
        int x=0,y=0; ChassisUart_GetLatest(&x,&y);
        check_i("解码 x(应=200)", x, 200);
        check_i("解码 y(应=205)", y, 205);
        clear_cap(); Move(x, y);
        check_i("servo_L_CCR(右小角=-30)", read_ccr(&t1, TIM_CHANNEL_1), servo_ccr(-30));
        check_i("servo_R_CCR(右小角=-25)", read_ccr(&t1, TIM_CHANNEL_2), servo_ccr(-25));
        check_i("电机A ch1(左前进=72)", read_ccr(&t2, TIM_CHANNEL_1), motor_ccr(72));
        check_i("电机B ch4(右前进=36)", read_ccr(&t2, TIM_CHANNEL_4), motor_ccr(36));
    }

    printf("[G] 错误校验和 (预期: 状态保持上一帧, 不被污染)\n");
    clear_cap(); ChassisUart_Init();
    ChassisUart_FeedByte(0xAA,0); ChassisUart_FeedByte(0x55,0);
    ChassisUart_FeedByte(200,0);  ChassisUart_FeedByte(50,0);
    ChassisUart_FeedByte(0x00,0);
    {
        int x=0,y=0; uint8_t ok = ChassisUart_GetLatest(&x,&y);
        check_i("坏帧后 valid(应=0)", ok, 0);
    }

    printf("[H] 端到端：PS2 发送(200,50) 帧 == 底盘接收解析\n");
    g_tx_len = 0;
    UART_RELEASE_SendJoystick(200, 50);
    {
        int ok = (g_tx_len == 5 &&
                  g_tx_buf[0]==0xAA && g_tx_buf[1]==0x55 &&
                  g_tx_buf[2]==200  && g_tx_buf[3]==50) ? 1 : 0;
        check_i("PS2发出的帧头+数据正确", ok, 1);

        clear_cap(); ChassisUart_Init();
        for (int i = 0; i < g_tx_len; i++) ChassisUart_FeedByte(g_tx_buf[i], 0);
        int x=0,y=0; ChassisUart_GetLatest(&x,&y);
        check_i("底盘解出 x(应=200)", x, 200);
        check_i("底盘解出 y(应=205)", y, 205);
    }

    printf("\n===== 结果：PASS=%d  FAIL=%d =====\n", g_pass, g_fail);
    return (g_fail == 0) ? 0 : 1;
}
