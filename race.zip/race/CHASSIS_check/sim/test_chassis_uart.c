#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "chassis_uart.h"

static int g_pass = 0, g_fail = 0;
#define CHECK(cond, msg) do { \
    if (cond) { g_pass++; printf("  PASS: %s\n", msg); } \
    else     { g_fail++; printf("  FAIL: %s\n", msg); } \
} while (0)

static void make_frame(uint8_t *f, uint8_t lx, uint8_t ly) {
    f[0] = CHASSIS_FRAME_H0;
    f[1] = CHASSIS_FRAME_H1;
    f[2] = lx;
    f[3] = ly;
    f[4] = ChassisUart_ComputeChecksum(lx, ly);
}

// 电脑上跑的测试，不用接板子
int main(void)
{
    printf("===== chassis_uart 仿真测试 =====\n");

    CHECK(ChassisUart_ComputeChecksum(0x80, 0x80) == 0xFF, "校验和(128,128)=0xFF (170+85+128+128=511→0xFF)");
    CHECK(ChassisUart_ComputeChecksum(0xFF, 0x00) == (uint8_t)(0xAA+0x55+0xFF+0x00), "校验和(255,0)正确");

    ChassisUart_Init();
    {
        int x=0,y=0;
        CHECK(ChassisUart_GetLatest(&x,&y)==0, "未收帧时 GetLatest 返回 0");
        CHECK(ChassisUart_IsTimeout(0)==1, "未收帧时 IsTimeout 返回 1（安全态）");
    }

    {
        uint8_t f[5]; make_frame(f, 200, 40);
        for (int i=0;i<5;i++) ChassisUart_FeedByte(f[i], 1000);
        int x=0,y=0;
        CHECK(ChassisUart_GetLatest(&x,&y)==1, "收帧后 GetLatest 返回 1");
        CHECK(x==200, "x 正确=200");
        CHECK(y==215, "y 经 INVERT_Y 翻转=215 (255-40)");
        CHECK(ChassisUart_IsTimeout(1200)==0, "收帧后 200ms 内不超时");
    }

    CHECK(ChassisUart_IsTimeout(1500)==1, "距上次收帧 500ms -> 超时(安全态)");

    ChassisUart_Init();
    {

        for (int i=0;i<10;i++) ChassisUart_FeedByte((uint8_t)(i*37), 2000);
        int x=0,y=0;
        CHECK(ChassisUart_GetLatest(&x,&y)==0, "喂垃圾后仍为无效");
        uint8_t f[5]; make_frame(f, 100, 100);
        for (int i=0;i<5;i++) ChassisUart_FeedByte(f[i], 3000);
        CHECK(ChassisUart_GetLatest(&x,&y)==1, "完整正确帧后变有效");
        CHECK(x==100 && y==155, "x=100, y=155(255-100)");
    }

    ChassisUart_Init();
    {
        int x=0,y=0;
        uint8_t fa[5]; make_frame(fa, 10, 20);
        for (int i=0;i<5;i++) ChassisUart_FeedByte(fa[i], 4000);
        CHECK(ChassisUart_GetLatest(&x,&y)==1 && x==10 && y==235, "帧A 接收正确");

        uint8_t fb[4] = {0x55, 0x30, 0x40, ChassisUart_ComputeChecksum(0x30,0x40)};
        for (int i=0;i<4;i++) ChassisUart_FeedByte(fb[i], 4100);

        uint8_t fc[5]; make_frame(fc, 0x50, 0x60);
        for (int i=0;i<5;i++) ChassisUart_FeedByte(fc[i], 4200);
        CHECK(ChassisUart_GetLatest(&x,&y)==1, "丢字节后第3帧仍能成帧");
        CHECK(x==0x50 && y==(255-0x60), "帧C x/y 正确 (丢1帧后已恢复)");
    }

    ChassisUart_Init();
    {

        uint8_t lx=0xAA, ly=0xAA;
        uint8_t f[5]; make_frame(f, lx, ly);
        for (int i=0;i<5;i++) ChassisUart_FeedByte(f[i], 4000);
        int x=0,y=0;
        CHECK(ChassisUart_GetLatest(&x,&y)==1, "LX=0xAA 也能正确成帧");
        CHECK(x==0xAA && y==(255-0xAA), "LX=0xAA, y 翻转正确");
    }

    printf("\n===== 结果：PASS=%d  FAIL=%d =====\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
