#include <stdio.h>
#include "motor.h"

uint16_t g_pwm = 0;
int16_t  g_enc_cnt = 0;
uint8_t  g_in1 = 0;
uint8_t  g_in2 = 0;
uint32_t SystemCoreClock = 72000000U;
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;

uint16_t g_pwm_at_dir_set = 0xFFFF;

HAL_StatusTypeDef HAL_GPIO_WritePin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin, GPIO_PinState PinState)
{
  (void)GPIOx;
  if (PinState == GPIO_PIN_SET) g_pwm_at_dir_set = g_pwm;
  if (GPIO_Pin == GPIO_PIN_12) g_in1 = (uint8_t)PinState;
  if (GPIO_Pin == GPIO_PIN_13) g_in2 = (uint8_t)PinState;
  return HAL_OK;
}
void HAL_GPIO_Init(GPIO_TypeDef *GPIOx, GPIO_InitTypeDef *GPIO_Init) { (void)GPIOx; (void)GPIO_Init; }
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin) { (void)GPIOx; (void)GPIO_Pin; return GPIO_PIN_RESET; }
void HAL_Delay(uint32_t Delay) { (void)Delay; }

static int g_pass = 0, g_fail = 0;
#define CHECK(cond, msg) do { \
  if (cond) { g_pass++; printf("  [PASS] %s\n", msg); } \
  else      { g_fail++; printf("  [FAIL] %s\n", msg); } \
} while (0)

static void motor_idle(void)
{
  MOTOR_SetSpeed(0);
  MOTOR_Update();
}

static void spin(int step)
{
  g_enc_cnt = (int16_t)(g_enc_cnt + step);
  MOTOR_Update();
}

// 电脑上跑的测试，不用接板子
int main(void)
{
  printf("==== 电机逻辑仿真（含换向/堵转保护）====\n");
  htim1.Init.Period = 7199;
  uint32_t arr = htim1.Init.Period;

  printf("[A] 编码器溢出安全累计（正向跨多圈）\n");
  g_enc_cnt = 0;
  MOTOR_Init();
  for (int i = 1; i <= 70000; i++) {
    g_enc_cnt = (int16_t)(i % 65536);
    MOTOR_Update();
  }
  CHECK(MOTOR_GetPosition() == 70000, "正向累计 70000 步后位置 == 70000（溢出处理正确）");
  CHECK(MOTOR_GetRPM() > 0, "正转时 RPM > 0");
  CHECK(MOTOR_GetAngleDeg() > 0, "正转时角度 > 0");

  printf("[B] 边界 0xFFFF->0 单步连续 +1\n");
  MOTOR_ResetPosition();
  g_enc_cnt = (int16_t)65534; MOTOR_Update();
  g_enc_cnt = (int16_t)65535; MOTOR_Update();
  int32_t before = MOTOR_GetPosition();
  g_enc_cnt = (int16_t)0;     MOTOR_Update();
  g_enc_cnt = (int16_t)1;     MOTOR_Update();
  CHECK(MOTOR_GetPosition() - before == 2, "跨 0xFFFF->0 两步各 +1（共 +2，无回绕错误）");

  printf("[C] 反转方向映射与位置递减\n");
  MOTOR_ResetPosition();
  g_enc_cnt = 0;
  motor_idle();
  MOTOR_SetSpeed(-50);
  spin(-2); spin(-2);
  CHECK(g_in1 == GPIO_PIN_RESET && g_in2 == GPIO_PIN_SET, "反转：IN1=0 IN2=1");
  CHECK(g_pwm == (uint16_t)((uint32_t)50u * arr / 100u), "反转 50%：PWM 占空比 = 50% × ARR");
  CHECK(g_pwm_at_dir_set == 0, "设置反转方向时 PWM 已为 0（零电流切换）");
  g_enc_cnt = (int16_t)-10; MOTOR_Update();
  CHECK(MOTOR_GetPosition() < 0, "反转时位置递减（<0）");
  CHECK(MOTOR_GetRPM() < 0, "反转时 RPM < 0（符号反映方向）");

  printf("[D] 正转方向映射、满速占空比、停止\n");
  motor_idle();
  MOTOR_SetSpeed(100);
  for (int i = 0; i < 4; i++) spin(2);
  CHECK(g_in1 == GPIO_PIN_SET && g_in2 == GPIO_PIN_RESET, "正转：IN1=1 IN2=0");
  CHECK(g_pwm == (uint16_t)arr, "满速 100%：PWM = ARR（满占空比）");
  CHECK(MOTOR_GetAppliedSpeed() == 100, "斜坡结束后实际施加速度追上指令 100%");
  motor_idle();
  CHECK(g_pwm == 0, "速度 0：PWM = 0");
  CHECK(g_in1 == GPIO_PIN_RESET && g_in2 == GPIO_PIN_RESET, "停止：IN1=IN2=0（滑行）");

  printf("[E] 速度限幅\n");
  MOTOR_SetSpeed(150);
  CHECK(MOTOR_GetSpeed() == 100, "超范围 +150 被限幅到 +100");
  MOTOR_SetSpeed(-200);
  CHECK(MOTOR_GetSpeed() == -100, "超范围 -200 被限幅到 -100");

  printf("[F] 机械臂齿轮减速(18:58) 与 ±180° 限位\n");
  motor_idle();

  g_enc_cnt = 0; MOTOR_ResetPosition();
  CHECK(MOTOR_GetArmAngleDeg() == 0.0f, "上电零点：机械臂角度 == 0");

  for (int i = 1; i <= 46; i++) { g_enc_cnt = (int16_t)i; MOTOR_Update(); }
  CHECK(MOTOR_GetArmAngleDeg() > 180.0f, "正向累计后机械臂角度 > 180°");
  CHECK(MOTOR_AtLimit() == 1, "到达正转限位(+180°) -> AtLimit()==1");
  CHECK(MOTOR_GetArmRPM() == (int16_t)((float)MOTOR_GetRPM() * (18.0f/58.0f)),
        "机械臂转速 = 电机转速 × 18/58");

  g_enc_cnt = 0; MOTOR_ResetPosition();
  for (int i = 1; i <= 46; i++) { g_enc_cnt = (int16_t)(-i); MOTOR_Update(); }
  CHECK(MOTOR_GetArmAngleDeg() < -180.0f, "反向累计后机械臂角度 < -180°");
  CHECK(MOTOR_AtLimit() == 2, "到达反转限位(-180°) -> AtLimit()==2");

  g_enc_cnt = 0; MOTOR_ResetPosition();
  for (int i = 1; i <= 20; i++) { g_enc_cnt = (int16_t)i; MOTOR_Update(); }
  CHECK(MOTOR_AtLimit() == 0, "臂角在 ±180° 内 -> AtLimit()==0");

  printf("[G] 换向死区：先卸载 PWM，再零电流切方向，再斜坡软启动\n");
  motor_idle();
  MOTOR_SetSpeed(100);
  for (int i = 0; i < 4; i++) spin(2);
  uint16_t pwm_before = g_pwm;
  CHECK(pwm_before == (uint16_t)arr && g_in1 == GPIO_PIN_SET, "换向前：正转满速稳定输出");

  MOTOR_SetSpeed(-100);
  CHECK(g_pwm == pwm_before, "SetSpeed 只登记目标，不碰 PWM/方向脚（不会瞬间全压反接）");

  g_pwm_at_dir_set = 0xFFFF;
  spin(2);
  CHECK(g_pwm == 0, "换向第 1 拍：PWM 立即归零");
  CHECK(g_in1 == GPIO_PIN_RESET && g_in2 == GPIO_PIN_RESET, "换向第 1 拍：IN1=IN2=0 输出高阻");
  CHECK(MOTOR_GetAppliedSpeed() == 0, "换向第 1 拍：实际施加速度 = 0");

  for (int t = 0; t < MOTOR_DIR_DEADTIME_TICKS; t++) {
    spin(2);
    CHECK(g_pwm == 0 && g_in1 == GPIO_PIN_RESET && g_in2 == GPIO_PIN_RESET,
          "死区期间保持输出高阻（绕组电流衰减、再生能量无回灌通路）");
  }

  g_pwm_at_dir_set = 0xFFFF;
  spin(2);
  CHECK(g_in1 == GPIO_PIN_RESET && g_in2 == GPIO_PIN_SET, "死区结束后才切到反转方向");
  CHECK(g_pwm_at_dir_set == 0, "切方向瞬间 PWM 已稳定为 0（零电流切换，桥臂无浪涌）");
  CHECK(g_pwm == (uint16_t)((uint32_t)MOTOR_RAMP_STEP_PCT * arr / 100u),
        "反向第一拍只给斜坡首档占空比");
  CHECK(g_pwm < pwm_before, "反向电压不是一步到满压（避免反电动势叠加出 2 倍堵转电流）");

  uint16_t prev_pwm = g_pwm;
  for (int i = 0; i < 3; i++) {
    spin(-2);
    CHECK(g_pwm > prev_pwm && g_in1 == GPIO_PIN_RESET && g_in2 == GPIO_PIN_SET,
          "反向斜坡逐拍升高、方向保持不变");
    prev_pwm = g_pwm;
  }
  CHECK(g_pwm == (uint16_t)arr, "斜坡结束达到反向满速");

  printf("[H] 起步软启动斜坡\n");
  motor_idle();
  MOTOR_SetSpeed(100);
  for (int pct = MOTOR_RAMP_STEP_PCT; pct <= 100; pct += MOTOR_RAMP_STEP_PCT) {
    spin(2);
    CHECK(g_pwm == (uint16_t)((uint32_t)pct * arr / 100u), "起步每拍按斜坡递增占空比");
  }

  MOTOR_SetSpeed(20); spin(2);
  CHECK(g_pwm == (uint16_t)((uint32_t)20u * arr / 100u), "减速立即跟随（限位屏蔽即时断电）");

  printf("[I] 堵转检测与断电锁存\n");
  motor_idle();
  MOTOR_SetSpeed(80);

  for (int i = 0; i < (MOTOR_STALL_TICKS + 8); i++) MOTOR_Update();
  CHECK(MOTOR_IsFault() == 1, "高占空比 + 编码器窗口内不动 -> 堵转保护锁存");
  CHECK(g_pwm == 0 && g_in1 == GPIO_PIN_RESET && g_in2 == GPIO_PIN_RESET,
        "锁存后输出被强制断开（H 桥零电流）");
  MOTOR_SetSpeed(90);
  for (int i = 0; i < 3; i++) MOTOR_Update();
  CHECK(g_pwm == 0 && MOTOR_IsFault() == 1, "未松手时持续断电，不会反复硬启");
  MOTOR_SetSpeed(0); MOTOR_Update();
  CHECK(MOTOR_IsFault() == 0, "松手回中自动解除锁存");
  MOTOR_SetSpeed(30);
  for (int i = 0; i < 2; i++) spin(2);
  CHECK(g_pwm > 0 && MOTOR_IsFault() == 0, "解锁后可正常重新起步");

  printf("\n============================================================\n");
  printf(" 结果：PASS=%d  FAIL=%d\n", g_pass, g_fail);
  printf("============================================================\n");
  return (g_fail == 0) ? 0 : 1;
}
