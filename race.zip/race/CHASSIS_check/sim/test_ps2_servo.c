#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include "ps2.h"
#include "servo.h"

/* 速度模式参数（与 main.c 中 USER CODE BEGIN PD 保持一致） */
#define JOY_DEADZONE  20
#define JOY_MAX_RATE  4.0f
#define BTN_STEP      3.0f

uint32_t g_ccr[4] = {0};
uint32_t sim_di_bit_index = 0;
uint8_t  sim_ps2_response[9] = {0};

TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
DWT_Type      g_dwt;
CoreDebug_Type g_coredebug;

HAL_StatusTypeDef HAL_GPIO_WritePin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin, GPIO_PinState PinState) {
    (void)GPIOx; (void)GPIO_Pin; (void)PinState;
    return HAL_OK;
}
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin) {
    if (GPIOx == GPIOA && GPIO_Pin == GPIO_PIN_4) {
        uint32_t bi = (sim_di_bit_index++) % 72;
        int byte = (int)(bi / 8);
        int bit  = (int)(bi % 8);
        uint8_t b = (byte < 9) ? sim_ps2_response[byte] : 0x00;
        return (((b >> bit) & 0x01U) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    }
    return GPIO_PIN_RESET;
}
void HAL_Delay(uint32_t Delay) { (void)Delay; }

uint32_t HAL_RCC_GetHCLKFreq(void) { return 0; }
HAL_StatusTypeDef HAL_TIM_PWM_Start(TIM_HandleTypeDef *htim, uint32_t Channel) {
    (void)htim; (void)Channel; return HAL_OK;
}

static int g_pass = 0, g_fail = 0;
#define CHECK(cond, msg) do { \
    if (cond) { g_pass++; printf("  [PASS] %s\n", msg); } \
    else     { g_fail++; printf("  [FAIL] %s\n", msg); } \
} while (0)

static void set_response(uint8_t mode, uint8_t btn1_raw, uint8_t btn2_raw,
                         uint8_t rx_lr, uint8_t rx_ud, uint8_t lx_lr, uint8_t lx_ud) {
    sim_ps2_response[0] = 0x73;
    sim_ps2_response[1] = mode;
    sim_ps2_response[2] = 0x5A;
    sim_ps2_response[3] = btn1_raw;
    sim_ps2_response[4] = btn2_raw;
    sim_ps2_response[5] = rx_lr;
    sim_ps2_response[6] = rx_ud;
    sim_ps2_response[7] = lx_lr;
    sim_ps2_response[8] = lx_ud;
    sim_di_bit_index = 0;
}

static uint32_t expect_ccr(float deg) {
    return (uint32_t)(500.0f + (deg / 180.0f) * 2000.0f + 0.5f);
}

static void sim_control(JOYSTICK_TypeDef *js) {

    int16_t ry_off = (int16_t)js->RJoy_UD - 128;
    int16_t ay = ry_off < 0 ? -ry_off : ry_off;
    if (ay > JOY_DEADZONE)
        SERVO_Rotate(SERVO_CH2, (-(float)ry_off / 128.0f) * JOY_MAX_RATE);

    if (js->btn1 & PS2_BTN_UP)    SERVO_Rotate(SERVO_CH1,  BTN_STEP);
    if (js->btn1 & PS2_BTN_DOWN)  SERVO_Rotate(SERVO_CH1, -BTN_STEP);

    static uint8_t l2_prev = 0, r2_prev = 0;
    static uint8_t c_state = 0, d_state = 0;
    uint8_t l2 = (js->btn2 & PS2_BTN_L2) ? 1 : 0;
    uint8_t r2 = (js->btn2 & PS2_BTN_R2) ? 1 : 0;
    if (l2 && !l2_prev) { c_state ^= 1; SERVO_SetTarget(SERVO_CH3, c_state ? 175.0f : 5.0f); }
    if (r2 && !r2_prev) { d_state ^= 1; SERVO_SetTarget(SERVO_CH4, d_state ? 175.0f : 5.0f); }
    l2_prev = l2; r2_prev = r2;
    SERVO_Update();
}

// 电脑上跑的测试，不用接板子
int main(void) {
    printf("============================================================\n");
    printf(" PS2 + 舵机 逻辑仿真测试（基于真实 ps2.c / servo.c）\n");
    printf("============================================================\n\n");

    printf("[测试组 1] PS2_ScanKey 协议解析\n");
    PS2_Init();

    set_response(0x73,
                 (uint8_t)(~PS2_BTN_SELECT),
                 (uint8_t)(~PS2_BTN_TRIANGLE),
                 0xFF, 0x00, 0xFF, 0x80);
    JOYSTICK_TypeDef js = {0};
    PS2_ScanKey(&js);
    CHECK(js.mode == 0x73, "mode == 0x73（模拟红灯模式）");
    CHECK(js.btn1 == PS2_BTN_SELECT, "btn1 解析出 SELECT（低有效已取反）");
    CHECK(js.btn2 == PS2_BTN_TRIANGLE, "btn2 解析出 TRIANGLE（△）");
    CHECK(js.RJoy_LR == 0xFF && js.RJoy_UD == 0x00, "右摇杆坐标还原 RX=0xFF RY=0x00");
    CHECK(js.LJoy_LR == 0xFF && js.LJoy_UD == 0x80, "左摇杆坐标还原 LX=0xFF LY=0x80");

    set_response(0x73, 0xFF, 0xFF, 0x80, 0x80, 0x80, 0x80);
    PS2_ScanKey(&js);
    CHECK(js.btn1 == 0x00, "全部松开时 btn1 == 0x00");
    CHECK(js.btn2 == 0x00, "全部松开时 btn2 == 0x00");
    CHECK(js.RJoy_LR == 0x80 && js.RJoy_UD == 0x80, "居中坐标 RX=RY=0x80");

    set_response(0x41, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00);
    PS2_ScanKey(&js);
    CHECK(js.mode == 0x41, "可识别数字模式 0x41（用于判断是否需要切模拟）");
    printf("\n");

    printf("[测试组 2] 舵机驱动算法\n");
    SERVO_Init();
    CHECK(g_ccr[0] == expect_ccr(SERVO_SAFE_ANGLE) &&
          g_ccr[1] == expect_ccr(SERVO_SAFE_ANGLE) &&
          g_ccr[2] == expect_ccr(SERVO_SAFE_ANGLE) &&
          g_ccr[3] == expect_ccr(SERVO_SAFE_ANGLE),
          "SERVO_Init 把四路都归位到安全角 5°（CCR=556）");

    SERVO_WriteAngle(SERVO_CH1, 90.0f);
    CHECK(g_ccr[0] == expect_ccr(90.0f), "CH1 写 90° -> CCR=1500");

    SERVO_WriteAngle(SERVO_CH2, 200.0f);
    CHECK(g_ccr[1] == expect_ccr(175.0f), "CH2 写 200° 被硬限位裁剪到 175°（防打齿）");

    SERVO_WriteAngle(SERVO_CH3, -50.0f);
    CHECK(g_ccr[2] == expect_ccr(5.0f), "CH3 写 -50° 被硬限位裁剪到 5°");

    SERVO_SetTarget(SERVO_CH4, 175.0f);
    float prev = 5.0f;
    int steps = 0;
    for (int i = 0; i < 100; i++) {
        SERVO_Update();
        steps++;

        float cur = ((float)g_ccr[3] - 500.0f) * 180.0f / 2000.0f;
        if (cur >= 174.9f) break;
        CHECK(cur >= prev - 0.01f, "缓动单调逼近（不回退）");
        prev = cur;
    }
    CHECK(g_ccr[3] == expect_ccr(175.0f), "CH4 缓动最终精确停在 175°（CCR=2444）");
    CHECK(steps <= 43, "5°->175° 最多 43 帧（170/4）到达，无无限循环");

    SERVO_Init();
    for (int i = 0; i < 200; i++) SERVO_Rotate(SERVO_CH1, 10.0f);
    CHECK(fabs(SERVO_GetAngle(SERVO_CH1) - 175.0f) < 0.001f, "Rotate +10×200 -> CH1 夹到 175°（不越界）");
    for (int i = 0; i < 200; i++) SERVO_Rotate(SERVO_CH1, -10.0f);
    CHECK(fabs(SERVO_GetAngle(SERVO_CH1) - 5.0f) < 0.001f, "Rotate -10×200 -> CH1 夹到 5°（不越界）");
    printf("\n");

    printf("[测试组 3] 主循环舵机速度控制（↑/↓->CH1，右摇杆Y->CH2，按住就转、松手就停、限位）\n");
    SERVO_Init();

    set_response(0x73, (uint8_t)(~PS2_BTN_UP), 0xFF, 0x80, 0x80, 0x80, 0x80);
    for (int i = 0; i < 200; i++) { PS2_ScanKey(&js); sim_control(&js); }
    CHECK(fabs(SERVO_GetAngle(SERVO_CH1) - 175.0f) < 0.6f, "按住↑ -> CH1(PB6)夹到 175° 上限");

    set_response(0x73, (uint8_t)(~PS2_BTN_DOWN), 0xFF, 0x80, 0x80, 0x80, 0x80);
    for (int i = 0; i < 200; i++) { PS2_ScanKey(&js); sim_control(&js); }
    CHECK(fabs(SERVO_GetAngle(SERVO_CH1) - 5.0f) < 0.6f, "按住↓ -> CH1(PB6)夹到 5° 下限");

    float a1 = SERVO_GetAngle(SERVO_CH1);
    set_response(0x73, 0xFF, 0xFF, 0x80, 0x80, 0x80, 0x80);
    for (int i = 0; i < 10; i++) { PS2_ScanKey(&js); sim_control(&js); }
    CHECK(fabs(SERVO_GetAngle(SERVO_CH1) - a1) < 0.001f, "松开(无按键) -> CH1 不动作（松手即停）");

    SERVO_Init();
    SERVO_WriteAngle(SERVO_CH1, 90.0f);
    set_response(0x73, (uint8_t)(~PS2_BTN_UP), 0xFF, 0x80, 0x80, 0x80, 0x80);
    for (int i = 0; i < 10; i++) { PS2_ScanKey(&js); sim_control(&js); }
    CHECK(SERVO_GetAngle(SERVO_CH1) > 119.0f && SERVO_GetAngle(SERVO_CH1) < 121.0f, "按住↑ 10 拍 -> CH1 约 +30°（BTN_STEP=3）");

    SERVO_Init();
    set_response(0x73, 0xFF, 0xFF, 0x80, 0x00, 0x80, 0x80);
    for (int i = 0; i < 200; i++) { PS2_ScanKey(&js); sim_control(&js); }
    CHECK(fabs(SERVO_GetAngle(SERVO_CH2) - 175.0f) < 0.6f, "RY满上 -> CH2(PB7)夹到 175° 上限");
    set_response(0x73, 0xFF, 0xFF, 0x80, 0xFF, 0x80, 0x80);
    for (int i = 0; i < 200; i++) { PS2_ScanKey(&js); sim_control(&js); }
    CHECK(fabs(SERVO_GetAngle(SERVO_CH2) - 5.0f) < 0.6f, "RY满下 -> CH2(PB7)夹到 5° 下限");

    SERVO_Init();
    SERVO_WriteAngle(SERVO_CH1, 90.0f);
    SERVO_WriteAngle(SERVO_CH2, 90.0f);
    set_response(0x73, (uint8_t)(~PS2_BTN_UP), 0xFF, 0x80, 0x00, 0x80, 0x80);
    for (int i = 0; i < 30; i++) { PS2_ScanKey(&js); sim_control(&js); }
    CHECK(SERVO_GetAngle(SERVO_CH1) > 90.5f, "↑ 与 RY 同按 -> CH1(↑)向 175 转动");
    CHECK(SERVO_GetAngle(SERVO_CH2) > 90.5f, "↑ 与 RY 同按 -> CH2(RY)也向 175 转动（两路独立）");

    SERVO_Init();
    set_response(0x73, 0xFF, (uint8_t)(~PS2_BTN_L2), 0x80, 0x80, 0x80, 0x80);
    PS2_ScanKey(&js); sim_control(&js);
    CHECK(SERVO_GetAngle(SERVO_CH3) > 5.5f, "L2 上升沿 -> CH3 开始转向 175°");
    set_response(0x73, 0xFF, (uint8_t)(~PS2_BTN_L2), 0x80, 0x80, 0x80, 0x80);
    PS2_ScanKey(&js); sim_control(&js);
    CHECK(SERVO_GetAngle(SERVO_CH3) > 5.5f, "L2 按住不放不二次翻转（仍向 175 缓动）");

    printf("\n============================================================\n");
    printf(" 结果：PASS=%d  FAIL=%d\n", g_pass, g_fail);
    printf("============================================================\n");
    return (g_fail == 0) ? 0 : 1;
}
