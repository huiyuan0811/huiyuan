#include <stdio.h>
#include <string.h>
#include "uart_release.h"

UART_HandleTypeDef huart2;
uint8_t  g_tx[16];
uint16_t g_tx_len = 0;
uint16_t g_tx_count = 0;

HAL_StatusTypeDef HAL_UART_Transmit(UART_HandleTypeDef *huart,
                                    uint8_t *pData,
                                    uint16_t Size,
                                    uint32_t Timeout)
{
  (void)huart; (void)Timeout;
  if (Size > sizeof(g_tx)) Size = (uint16_t)sizeof(g_tx);
  memcpy(g_tx, pData, Size);
  g_tx_len = Size;
  g_tx_count++;
  return HAL_OK;
}

static int g_pass = 0, g_fail = 0;
#define CHECK(cond, msg) do { \
    if (cond) { g_pass++; printf("  [PASS] %s\n", msg); } \
    else      { g_fail++; printf("  [FAIL] %s\n", msg); } \
  } while (0)

// 电脑上跑的测试，不用接板子
int main(void)
{
  printf("================ uart_release 仿真测试 ================\n");

  printf("[测试组 A] 初始化发中立帧\n");
  g_tx_count = 0;
  UART_RELEASE_Init();
  CHECK(g_tx_count == 1, "UART_RELEASE_Init 发送了 1 帧");
  CHECK(g_tx_len == UART_RELEASE_FRAME_LEN, "帧长 = 5 字节");
  CHECK(g_tx[0] == UART_RELEASE_HDR0 && g_tx[1] == UART_RELEASE_HDR1,
        "帧头 = 0xAA 0x55");
  CHECK(g_tx[2] == 128 && g_tx[3] == 128, "中立 LX=LY=128");
  CHECK(g_tx[4] == (uint8_t)((0xAA + 0x55 + 128 + 128) & 0xFF),
        "中立帧校验和正确 (0xFF)");

  printf("[测试组 B] 发送任意摇杆值\n");
  g_tx_count = 0;
  HAL_StatusTypeDef st = UART_RELEASE_SendJoystick(0x00, 0xFF);
  CHECK(st == HAL_OK, "返回 HAL_OK");
  CHECK(g_tx[0] == 0xAA && g_tx[1] == 0x55, "帧头正确");
  CHECK(g_tx[2] == 0x00, "LX 直接映射为 0x00");
  CHECK(g_tx[3] == 0xFF, "LY 直接映射为 0xFF");
  CHECK(g_tx[4] == (uint8_t)((0xAA + 0x55 + 0x00 + 0xFF) & 0xFF),
        "校验和正确 (LX=0,LY=255 -> 0xFE)");
  CHECK(g_tx_count == 1, "本次调用发送了 1 帧");

  st = UART_RELEASE_SendJoystick(0xFF, 0x00);
  CHECK(g_tx[2] == 0xFF && g_tx[3] == 0x00, "反向映射正确");
  CHECK(g_tx[4] == (uint8_t)((0xAA + 0x55 + 0xFF + 0x00) & 0xFF),
        "校验和正确 (LX=255,LY=0 -> 0xFE)");

  printf("[测试组 C] 连续相同值每拍必发\n");
  g_tx_count = 0;
  for (int i = 0; i < 5; i++) UART_RELEASE_SendJoystick(100, 150);
  CHECK(g_tx_count == 5, "连续 5 次发送 -> 5 帧（无抑制）");
  CHECK(g_tx[2] == 100 && g_tx[3] == 150, "最后一帧 LX=100 LY=150");
  CHECK(g_tx[4] == (uint8_t)((0xAA + 0x55 + 100 + 150) & 0xFF),
        "校验和正确 (100+150 -> 0x99)");

  printf("[测试组 D] SendNeutral 强制中立\n");
  g_tx_count = 0;
  UART_RELEASE_SendNeutral();
  CHECK(g_tx_count == 1, "SendNeutral 发送 1 帧");
  CHECK(g_tx[2] == 128 && g_tx[3] == 128, "SendNeutral 内容=中立(128,128)");

  printf("[测试组 E] 校验和覆盖帧头+数据\n");
  uint8_t lx = 200, ly = 55;
  UART_RELEASE_SendJoystick(lx, ly);
  uint8_t expect = (uint8_t)((UART_RELEASE_HDR0 + UART_RELEASE_HDR1 + lx + ly) & 0xFF);
  CHECK(g_tx[4] == expect, "校验和 = (0xAA+0x55+LX+LY)&0xFF 恒成立");

  printf("[测试组 F] 仅变化时发送（省带宽）\n");
  g_tx_count = 0;
  st = UART_RELEASE_SendJoystickIfChanged(128, 128);
  CHECK(st == HAL_OK, "首次调用(128,128) -> 发送 HAL_OK");
  CHECK(g_tx_count == 1, "首次发送 1 帧");
  CHECK(g_tx[2] == 128 && g_tx[3] == 128, "首帧内容 128,128");

  st = UART_RELEASE_SendJoystickIfChanged(128, 128);
  CHECK(st == HAL_BUSY, "相同值 -> HAL_BUSY(跳过语义)");
  CHECK(g_tx_count == 1, "相同值不增加发送计数(仍为1)");

  st = UART_RELEASE_SendJoystickIfChanged(130, 128);
  CHECK(st == HAL_OK, "LX 变化(130,128) -> HAL_OK");
  CHECK(g_tx_count == 2, "变化后发送计数=2");
  CHECK(g_tx[2] == 130, "新帧 LX=130");

  st = UART_RELEASE_SendJoystickIfChanged(130, 128);
  CHECK(g_tx_count == 2, "再次相同不发送(仍为2)");

  st = UART_RELEASE_SendJoystickIfChanged(130, 131);
  CHECK(st == HAL_OK, "LY 变化(130,131) -> HAL_OK");
  CHECK(g_tx_count == 3, "LY 变化后发送计数=3");
  CHECK(g_tx[3] == 131, "新帧 LY=131");

  printf("=======================================================\n");
  printf("结果：%d PASS / %d FAIL\n", g_pass, g_fail);
  return (g_fail == 0) ? 0 : 1;
}
