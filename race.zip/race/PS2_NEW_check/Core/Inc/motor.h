/**
  ******************************************************************************
  * @file    motor.h
  * @brief   N20 带编码器直流减速电机驱动（TB6612FNG 类 H 桥 + 霍尔编码器）
  ******************************************************************************
  */
#ifndef __MOTOR_H
#define __MOTOR_H

#include "main.h"
#include "tim.h"

#define MOTOR_ENC_PPR      7
// 减速比暂按 1 计算，装减速箱后需修改
#define MOTOR_GEAR_RATIO   1

#define ARM_DRIVE_RATIO    (18.0f/58.0f)

#define ARM_LIMIT_DEG      180.0f
#define MOTOR_PWM_FREQ_HZ  10000

#define MOTOR_TICK_MS             50
#define MOTOR_DIR_DEADTIME_TICKS   2
#define MOTOR_RAMP_STEP_PCT       25
#define MOTOR_STALL_MIN_PCT       50
#define MOTOR_STALL_TICKS         12
#define MOTOR_STALL_MIN_COUNTS     3

#define MOTOR_IN1_PORT     GPIOB
#define MOTOR_IN1_PIN      GPIO_PIN_12
#define MOTOR_IN2_PORT     GPIOB
#define MOTOR_IN2_PIN      GPIO_PIN_13

void    MOTOR_Init(void);

// 此处只登记速度，实际生效由 Update 完成
void    MOTOR_SetSpeed(int16_t speed_pct);

void    MOTOR_Brake(void);

void    MOTOR_Update(void);
int32_t MOTOR_GetPosition(void);
void    MOTOR_ResetPosition(void);
int16_t MOTOR_GetRPM(void);
float   MOTOR_GetAngleDeg(void);
float   MOTOR_GetArmAngleDeg(void);
int16_t MOTOR_GetArmRPM(void);
uint8_t MOTOR_AtLimit(void);
int16_t MOTOR_GetSpeed(void);
int16_t MOTOR_GetAppliedSpeed(void);
uint8_t MOTOR_IsFault(void);
void    MOTOR_ClearFault(void);

#endif
