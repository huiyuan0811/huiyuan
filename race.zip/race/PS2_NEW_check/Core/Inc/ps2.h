#ifndef __PS2_H
#define __PS2_H

#include "main.h"

// 换板子时只需改这几个引脚
#define PS2_DI_PORT   GPIOA
#define PS2_DI_PIN    GPIO_PIN_4
#define PS2_CMD_PORT  GPIOA
#define PS2_CMD_PIN   GPIO_PIN_5
#define PS2_CS_PORT   GPIOA
#define PS2_CS_PIN    GPIO_PIN_6
#define PS2_CLK_PORT  GPIOA
#define PS2_CLK_PIN   GPIO_PIN_7

#define PS2_BTN_SELECT   (1u << 0)
#define PS2_BTN_L3       (1u << 1)
#define PS2_BTN_R3       (1u << 2)
#define PS2_BTN_START    (1u << 3)
#define PS2_BTN_UP       (1u << 4)
#define PS2_BTN_RIGHT    (1u << 5)
#define PS2_BTN_DOWN     (1u << 6)
#define PS2_BTN_LEFT     (1u << 7)

#define PS2_BTN_L2       (1u << 0)
#define PS2_BTN_R2       (1u << 1)
#define PS2_BTN_L1       (1u << 2)
#define PS2_BTN_R1       (1u << 3)
#define PS2_BTN_TRIANGLE (1u << 4)
#define PS2_BTN_CIRCLE   (1u << 5)
#define PS2_BTN_CROSS    (1u << 6)
#define PS2_BTN_SQUARE   (1u << 7)

typedef struct {
  uint8_t mode;
  uint8_t btn1;
  uint8_t btn2;
  uint8_t RJoy_LR;
  uint8_t RJoy_UD;
  uint8_t LJoy_LR;
  uint8_t LJoy_UD;
} JOYSTICK_TypeDef;

void PS2_Init(void);
void PS2_ScanKey(JOYSTICK_TypeDef *js);
void PS2_SetAnalogMode(void);

#endif
