/**
  ******************************************************************************
  * @file    servo.h
  * @brief   MG996R 舵机驱动（TIM4 四路 50Hz PWM，带安全限位与缓动）
  *
  * 舵机约定（与 MG996R  datasheet / 你提供的图片一致）：
  *   - 控制周期 20ms (50Hz)；脉冲 0.5ms=0°、2.5ms=180°
  *   - 红线=VCC(5~6V 独立供电)  棕线=GND(与 MCU 共地)  橙线=信号
  *   - 本模块强制把角度夹在 [SERVO_MIN_ANGLE, SERVO_MAX_ANGLE] = [5,175] 度，
  *     绝不直接写到范围外，防止舵机齿轮被打坏 / 堵转。
  *
  * 引脚分配（需在 CubeMX 中把 TIM4 的四个通道配成 PWM，见说明）：
  *   SERVO_CH1 -> PB6 (TIM4_CH1)
  *   SERVO_CH2 -> PB7 (TIM4_CH2)
  *   SERVO_CH3 -> PB8 (TIM4_CH3)
  *   SERVO_CH4 -> PB9 (TIM4_CH4)
  ******************************************************************************
  */
#ifndef __SERVO_H
#define __SERVO_H

#include "stm32f1xx_hal.h"
#include "tim.h"

#define SERVO_CH1  0
#define SERVO_CH2  1
#define SERVO_CH3  2
#define SERVO_CH4  3

#define SERVO_MIN_ANGLE  5.0f
#define SERVO_MAX_ANGLE  175.0f

#define SERVO_SAFE_ANGLE 5.0f

#define SERVO_RAMP_STEP  4.0f

/**
  * @brief  启动 TIM4 四路 PWM，并把所有舵机先归位到安全角 SERVO_SAFE_ANGLE (5°)。
  *         必须在 CubeMX 已配置并使能 TIM4 后才能调用（即 htim4 已存在）。
  */
void SERVO_Init(void);

/**
  * @brief  立即把某路舵机写到指定角度（带硬限位裁剪）。
  *         用于 A/B 两路由右摇杆 Y 直接连续控制（摇杆本身是平滑的，无需缓动）。
  * @param  ch    SERVO_CH1~SERVO_CH4
  * @param  angle 目标角度（度），超出 [5,175] 会被裁剪。
  */
void SERVO_WriteAngle(uint8_t ch, float angle);

/**
  * @brief  设定某路舵机的目标角度（带硬限位裁剪），实际角度由 SERVO_Update 缓动逼近。
  *         用于 C/D 两路由 L2/R2 触发的 5°<->175° 切换，避免瞬间跳转。
  */
void SERVO_SetTarget(uint8_t ch, float angle);

/**
  * @brief  周期调用：把每路舵机当前角度按 SERVO_RAMP_STEP 缓动逼近目标角。
  *         建议放在主循环（每 50ms 一次即可），不要放在中断里。
  */
void SERVO_Update(void);

/**
  * @brief  增量（速度）控制：相对当前角度再移动 delta_deg 度（带硬限位裁剪）。
  *         用于“按住就一直转、松开就停”的速度模式——每个控制周期把增量累加到当前角度上。
  *         delta_deg > 0 朝增大方向转，< 0 朝减小方向转；
  *         到 [SERVO_MIN_ANGLE, SERVO_MAX_ANGLE] = [5,175] 边界后自动停住，不会打齿/堵转。
  */
// 按住持续转动，松开停止
void SERVO_Rotate(uint8_t ch, float delta_deg);

/**
  * @brief  读取某路舵机当前角度（度），范围已被裁剪在 [5,175]。
  */
float SERVO_GetAngle(uint8_t ch);

#endif
