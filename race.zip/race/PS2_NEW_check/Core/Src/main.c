/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "ps2.h"
#include "servo.h"
#include "motor.h"
#include "uart_release.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define JOY_DEADZONE  20
#define JOY_MAX_RATE  4.0f
#define BTN_STEP      3.0f

#define JOG_MODE_ENABLE  0

#define JOG_CH_TH2      SERVO_CH1
#define JOG_CH_TH3      SERVO_CH2
#define JOG_SIGN_TH2    0
#define JOG_SIGN_TH3    0
// 还没有标定，先设为 0
#define JOG_POSE_CALIBRATED 0

#if (JOG_MODE_ENABLE && (JOG_SIGN_TH2 == 0 || JOG_SIGN_TH3 == 0 || !JOG_POSE_CALIBRATED))
#error "JOG: 标定未完成——需 2 个 SIGN(+1/-1)、基准姿态的 S1/S2 填入 S_AT_STEP、再把 JOG_POSE_CALIBRATED 置 1"
#endif

#define JOG_FLIP_U      0
#define JOG_FLIP_V      0

#define JOG_L2        400.0f
#define JOG_L3        400.0f
#define JOG_TH2_0      85.466f
#define JOG_TH3_0    -104.834f

#define JOG_S2_AT_STEP  90.0f
#define JOG_S3_AT_STEP  90.0f

#define JOG_HOME_STEP   3.0f

#define JOG_STEP_MM    2.0f
#define JOG_MAX_DS     3.0f
#define JOG_DET_MIN    0.10f

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
volatile uint8_t ps2_scan_flag = 0;
#if JOG_MODE_ENABLE

static float jog_th2 = JOG_TH2_0;
static float jog_th3 = JOG_TH3_0;

static uint8_t jog_homing = 1;
#endif
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#if JOG_MODE_ENABLE
#include <math.h>
#define JOG_D2R  0.01745329252f
#define JOG_R2D  57.29577951f

static void JOG_InitAngles(void)
{
  jog_th2 = JOG_TH2_0;
  jog_th3 = JOG_TH3_0;
  jog_homing = 1;
  if (JOG_S2_AT_STEP < SERVO_MIN_ANGLE || JOG_S2_AT_STEP > SERVO_MAX_ANGLE ||
      JOG_S3_AT_STEP < SERVO_MIN_ANGLE || JOG_S3_AT_STEP > SERVO_MAX_ANGLE)
  {
    jog_homing = 2;
    printf("JOG ERR: S_AT_STEP 必须在 [5,175] 内，保持锁定不动\r\n");
  }
}

static void JOG_HomeStep(void)
{
  float e2 = JOG_S2_AT_STEP - SERVO_GetAngle(JOG_CH_TH2);
  float e3 = JOG_S3_AT_STEP - SERVO_GetAngle(JOG_CH_TH3);
  float d2 = (e2 >  JOG_HOME_STEP) ?  JOG_HOME_STEP : ((e2 < -JOG_HOME_STEP) ? -JOG_HOME_STEP : e2);
  float d3 = (e3 >  JOG_HOME_STEP) ?  JOG_HOME_STEP : ((e3 < -JOG_HOME_STEP) ? -JOG_HOME_STEP : e3);
  if (d2 != 0.0f) SERVO_Rotate(JOG_CH_TH2, d2);
  if (d3 != 0.0f) SERVO_Rotate(JOG_CH_TH3, d3);
  if (fabsf(e2) <= JOG_HOME_STEP && fabsf(e3) <= JOG_HOME_STEP)
  {
    jog_homing = 0;
    printf("JOG: HOMED th2=%.1f th3=%.1f\r\n", jog_th2, jog_th3);
  }
}

static void JOG_Move(float dr, float dz)
{
  float a2 = jog_th2 * JOG_D2R, a3 = jog_th3 * JOG_D2R;
  float c2 = cosf(a2), s2 = sinf(a2), c3 = cosf(a3), s3 = sinf(a3);
  float sin_diff = s3 * c2 - s2 * c3;
  if (fabsf(sin_diff) < JOG_DET_MIN) return;
  float det = JOG_L2 * JOG_L3 * sin_diff;
  float dth2 = ( JOG_L3 * c3 * dr + JOG_L3 * s3 * dz) / det;
  float dth3 = (-JOG_L2 * c2 * dr - JOG_L2 * s2 * dz) / det;
  float ds2 = dth2 * JOG_R2D / (float)JOG_SIGN_TH2;
  float ds3 = dth3 * JOG_R2D / (float)JOG_SIGN_TH3;

  float m = fabsf(ds2) > fabsf(ds3) ? fabsf(ds2) : fabsf(ds3);
  if (m > JOG_MAX_DS)
  {
    float k = JOG_MAX_DS / m;
    ds2 *= k;  ds3 *= k;  dth2 *= k;  dth3 *= k;
  }

  SERVO_Rotate(JOG_CH_TH2, ds2);
  SERVO_Rotate(JOG_CH_TH3, ds3);
  jog_th2 += dth2 * JOG_R2D;
  jog_th3 += dth3 * JOG_R2D;
}
#endif
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();

  // 状态行不换行，需要关掉缓冲才会输出
  setvbuf(stdout, NULL, _IONBF, 0);
  MX_TIM4_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  PS2_Init();

  JOYSTICK_TypeDef tmp = {0};
  for (uint8_t i = 0; i < 10; i++) {
    PS2_SetAnalogMode();
    HAL_Delay(10);
    PS2_ScanKey(&tmp);
    if (tmp.mode == 0x73) break;
  }

  HAL_TIM_Base_Start_IT(&htim3);

  SERVO_Init();

  MOTOR_Init();

  UART_RELEASE_Init();
#if JOG_MODE_ENABLE
  JOG_InitAngles();
  printf("JOG: L2=L3=400mm Sref=%.1f/%.1f HOMING... (留出臂的活动空间)\r\n",
         JOG_S2_AT_STEP, JOG_S3_AT_STEP);
#endif
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

    if (ps2_scan_flag)
    {
      ps2_scan_flag = 0;

      JOYSTICK_TypeDef my_joystick = {0};
      PS2_ScanKey(&my_joystick);

      {
        // 左摇杆交给底盘，这边不用它控臂
        uint8_t lx = my_joystick.LJoy_LR;
        uint8_t ly = my_joystick.LJoy_UD;
        uint32_t now = HAL_GetTick();
        static uint32_t last_heartbeat_tick = 0;

        if (UART_RELEASE_SendJoystickIfChanged(lx, ly) == HAL_BUSY) {
          if ((now - last_heartbeat_tick) >= 200U) {
            // 只在变化时发送会触发超时，所以定时补发一帧
            UART_RELEASE_SendJoystick(lx, ly);
            last_heartbeat_tick = now;
          }
        } else {
          last_heartbeat_tick = now;
        }
      }

#if JOG_MODE_ENABLE

      {
        if (jog_homing == 1) JOG_HomeStep();
        else if (jog_homing == 0)
        {
        int16_t ry_off = (int16_t)my_joystick.RJoy_UD - 128;
        int16_t ay = ry_off < 0 ? -ry_off : ry_off;
        float dr = 0.0f, dz = 0.0f;
        if (ay > JOY_DEADZONE) dr = (-(float)ry_off / 128.0f) * JOG_STEP_MM;
        if (my_joystick.btn1 & PS2_BTN_UP)   dz += JOG_STEP_MM;
        if (my_joystick.btn1 & PS2_BTN_DOWN) dz -= JOG_STEP_MM;
#if JOG_FLIP_U
        dr = -dr;
#endif
#if JOG_FLIP_V
        dz = -dz;
#endif
        if (dr != 0.0f || dz != 0.0f) JOG_Move(dr, dz);
        }
      }
#else

      {
        int16_t ry_off = (int16_t)my_joystick.RJoy_UD - 128;
        int16_t ay = ry_off < 0 ? -ry_off : ry_off;
        if (ay > JOY_DEADZONE)
          SERVO_Rotate(SERVO_CH2, (-(float)ry_off / 128.0f) * JOY_MAX_RATE);
      }

      {
        if (my_joystick.btn1 & PS2_BTN_UP)    SERVO_Rotate(SERVO_CH1,  BTN_STEP);
        if (my_joystick.btn1 & PS2_BTN_DOWN)  SERVO_Rotate(SERVO_CH1, -BTN_STEP);
      }
#endif

      static uint8_t l2_prev = 0, r2_prev = 0;
      static uint8_t c_state = 0, d_state = 0;
      uint8_t l2 = (my_joystick.btn2 & PS2_BTN_L2) ? 1 : 0;
      uint8_t r2 = (my_joystick.btn2 & PS2_BTN_R2) ? 1 : 0;
      if (l2 && !l2_prev) { c_state ^= 1; SERVO_SetTarget(SERVO_CH3, c_state ? 175.0f : 5.0f); }
      if (r2 && !r2_prev) { d_state ^= 1; SERVO_SetTarget(SERVO_CH4, d_state ? 175.0f : 5.0f); }
      l2_prev = l2; r2_prev = r2;
      SERVO_Update();

      {
        float arm_ang = MOTOR_GetArmAngleDeg();
        int16_t rx_off = (int16_t)my_joystick.RJoy_LR - 128;
        int16_t sp = 0;
        if (rx_off < -JOY_DEADZONE || rx_off > JOY_DEADZONE) {
          sp = (int16_t)(((float)rx_off / 128.0f) * 100.0f);
        }

        if (sp > 0 && arm_ang >=  ARM_LIMIT_DEG) sp = 0;
        if (sp < 0 && arm_ang <= -ARM_LIMIT_DEG) sp = 0;
        MOTOR_SetSpeed(sp);
      }

      // 电机每 50ms 推进一次，只设速度不会生效
      MOTOR_Update();
      /* ========================================================================== */

      {

        float s1 = SERVO_GetAngle(SERVO_CH1);
        float s2 = SERVO_GetAngle(SERVO_CH2);
        float s3 = SERVO_GetAngle(SERVO_CH3);
        float s4 = SERVO_GetAngle(SERVO_CH4);
        char c3 = (s3 > 90.0f) ? 'C' : 'O';
        char c4 = (s4 > 90.0f) ? 'C' : 'O';

        float arm_ang  = MOTOR_GetArmAngleDeg();
        int16_t arm_rpm = MOTOR_GetArmRPM();
        int16_t mtr_rpm = MOTOR_GetRPM();
        char lim_ch;
        uint8_t lim = MOTOR_AtLimit();
        lim_ch = (lim == 1) ? '+' : (lim == 2) ? '-' : ' ';

        char line[320];
        int len = snprintf(line, sizeof(line),
          "MODE:%02X %s | LX:%3u LY:%3u RX:%3u RY:%3u | S1:%5.1f S2:%5.1f S3:%5.1f%c S4:%5.1f%c | M:%4d%% A:%4d MRPM:%5d ARPM:%5d ANG:%7.1f LIM:%c FLT:%c | ",
          my_joystick.mode, (my_joystick.mode == 0x73 ? "AN" : "DG"),
          my_joystick.LJoy_LR, my_joystick.LJoy_UD,
          my_joystick.RJoy_LR, my_joystick.RJoy_UD,
          s1, s2, s3, c3, s4, c4,
          MOTOR_GetSpeed(), MOTOR_GetAppliedSpeed(), mtr_rpm, arm_rpm, arm_ang,
          lim_ch, MOTOR_IsFault() ? 'S' : '-');

        char keybuf[70];
        int k = snprintf(keybuf, sizeof(keybuf), "%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s",
          (my_joystick.btn1 & PS2_BTN_UP)      ? "UP "  : "",
          (my_joystick.btn1 & PS2_BTN_DOWN)    ? "DN "  : "",
          (my_joystick.btn1 & PS2_BTN_LEFT)    ? "LF "  : "",
          (my_joystick.btn1 & PS2_BTN_RIGHT)   ? "RG "  : "",
          (my_joystick.btn1 & PS2_BTN_SELECT)  ? "SEL " : "",
          (my_joystick.btn1 & PS2_BTN_START)   ? "ST "  : "",
          (my_joystick.btn1 & PS2_BTN_L3)      ? "L3 "  : "",
          (my_joystick.btn1 & PS2_BTN_R3)      ? "R3 "  : "",
          (my_joystick.btn2 & PS2_BTN_L1)      ? "L1 "  : "",
          (my_joystick.btn2 & PS2_BTN_R1)      ? "R1 "  : "",
          (my_joystick.btn2 & PS2_BTN_L2)      ? "L2 "  : "",
          (my_joystick.btn2 & PS2_BTN_R2)      ? "R2 "  : "",
          (my_joystick.btn2 & PS2_BTN_TRIANGLE)? "TRI " : "",
          (my_joystick.btn2 & PS2_BTN_CIRCLE)  ? "CIR " : "",
          (my_joystick.btn2 & PS2_BTN_CROSS)   ? "X "   : "",
          (my_joystick.btn2 & PS2_BTN_SQUARE)  ? "SQ "  : "");
        if (k == 0) snprintf(keybuf, sizeof(keybuf), "-- ");
        len += snprintf(line + len, sizeof(line) - len, "BTN: %s", keybuf);
#if JOG_MODE_ENABLE

        len += snprintf(line + len, sizeof(line) - len, " TH:%.0f/%.0f %s",
                        jog_th2, jog_th3,
                        jog_homing ? (jog_homing == 1 ? "HOMING" : "JOG-ERR") : "READY");
#endif

#if JOG_MODE_ENABLE
        while (len < 260) { line[len++] = ' '; }
#else
        while (len < 240) { line[len++] = ' '; }
#endif
        line[len] = '\0';
        printf("%s\r", line);
      }
    }

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/**
  * @brief  TIM 周期溢出回调。仅置标志位，不做任何耗时操作（PS2 读取/printf 都在主循环）。
  * @note   TIM3 在 CubeMX 中配置；若该回调被其它 TIM 共用，注意先判断 htim->Instance。
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM3)
  {
    ps2_scan_flag = 1;
  }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */

  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */

  /* USER CODE END 6 */
}
#endif
