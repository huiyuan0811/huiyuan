/**
  ******************************************************************************
  * @file    motor.c
  * @brief   N20 带编码器直流减速电机驱动实现
  *          TIM1_CH1(PA8) 出 PWM 调速；PB12/13 控制方向；TIM2(PA0/1) 正交解码编码器
  ******************************************************************************
  */
#include "motor.h"

static int32_t s_position = 0;
// 编码器 16 位会回绕，用 int16_t 相减即可处理
static int16_t s_prev_cnt = 0;
static int32_t s_last_delta = 0;

static int16_t s_target = 0;
static int16_t s_applied = 0;
static int8_t  s_dir = 0;
static uint8_t s_dead = 0;
// 堵转后锁存，需要手动清除
static uint8_t s_fault = 0;
static uint8_t s_stall_ticks = 0;
static int32_t s_stall_sum = 0;

// 换向先断电滑行，直接反向可能损坏驱动
static void hw_coast(void)
{
  HAL_GPIO_WritePin(MOTOR_IN1_PORT, MOTOR_IN1_PIN, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(MOTOR_IN2_PORT, MOTOR_IN2_PIN, GPIO_PIN_RESET);
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
  s_dir = 0;
  s_applied = 0;
}

static void hw_set_dir(int8_t dir)
{
  if (dir > 0) {
    HAL_GPIO_WritePin(MOTOR_IN1_PORT, MOTOR_IN1_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(MOTOR_IN2_PORT, MOTOR_IN2_PIN, GPIO_PIN_RESET);
  } else {
    HAL_GPIO_WritePin(MOTOR_IN1_PORT, MOTOR_IN1_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(MOTOR_IN2_PORT, MOTOR_IN2_PIN, GPIO_PIN_SET);
  }
  s_dir = dir;
}

static void hw_set_pulse(int16_t mag)
{
  uint16_t pulse = (uint16_t)((uint32_t)(mag < 0 ? -mag : mag) * htim1.Init.Period / 100u);
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, pulse);
}

static void stall_reset(void)
{
  s_stall_ticks = 0;
  s_stall_sum = 0;
}

void MOTOR_Init(void)
{

  HAL_GPIO_WritePin(MOTOR_IN1_PORT, MOTOR_IN1_PIN, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(MOTOR_IN2_PORT, MOTOR_IN2_PIN, GPIO_PIN_RESET);

  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  __HAL_TIM_MOE_ENABLE(&htim1);
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);

  HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);

  s_position = 0;
  s_prev_cnt = (int16_t)__HAL_TIM_GET_COUNTER(&htim2);
  s_last_delta = 0;
  s_target = 0;
  s_applied = 0;
  s_dir = 0;
  s_dead = 0;
  s_fault = 0;
  stall_reset();
}

void MOTOR_SetSpeed(int16_t speed_pct)
{
  if (speed_pct > 100)  speed_pct = 100;
  if (speed_pct < -100) speed_pct = -100;

  s_target = speed_pct;
}

void MOTOR_Brake(void)
{

  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
  HAL_GPIO_WritePin(MOTOR_IN1_PORT, MOTOR_IN1_PIN, GPIO_PIN_SET);
  HAL_GPIO_WritePin(MOTOR_IN2_PORT, MOTOR_IN2_PIN, GPIO_PIN_SET);
  s_target = 0;
  s_applied = 0;
  s_dir = 0;
  s_dead = 0;
  s_fault = 0;
  stall_reset();
}

void MOTOR_Update(void)
{

  int16_t cnt = (int16_t)__HAL_TIM_GET_COUNTER(&htim2);
  int16_t delta = cnt - s_prev_cnt;
  s_prev_cnt = cnt;
  s_position += delta;
  s_last_delta = delta;

  if (s_fault) {
    hw_coast();
    stall_reset();
    if (s_target == 0) s_fault = 0;
    return;
  }

  if (s_dead > 0) {
    hw_coast();
    stall_reset();
    s_dead--;
    return;
  }

  int8_t want = (s_target > 0) ? 1 : (s_target < 0) ? -1 : 0;

  if (want != 0 && s_dir != 0 && want != s_dir) {
    hw_coast();
    s_dead = MOTOR_DIR_DEADTIME_TICKS;
    stall_reset();
    return;
  }

  if (want == 0) {
    hw_coast();
    stall_reset();
    return;
  }

  if (s_dir != want) hw_set_dir(want);

  int16_t mag = (s_target > 0) ? s_target : -s_target;
  int16_t cur = (s_applied > 0) ? s_applied : -s_applied;
  if (mag > cur) {
    cur += MOTOR_RAMP_STEP_PCT;
    if (cur > mag) cur = mag;
  } else {
    cur = mag;
  }
  s_applied = (want > 0) ? cur : -cur;
  hw_set_pulse(cur);

  if (cur >= MOTOR_STALL_MIN_PCT) {
    s_stall_sum += s_last_delta;
    if (++s_stall_ticks >= MOTOR_STALL_TICKS) {
      int32_t sum = (s_stall_sum < 0) ? -s_stall_sum : s_stall_sum;
      if (sum < MOTOR_STALL_MIN_COUNTS) {
        s_fault = 1;
        hw_coast();
      }
      stall_reset();
    }
  } else {
    stall_reset();
  }
}

int32_t MOTOR_GetPosition(void) { return s_position; }
void    MOTOR_ResetPosition(void)
{
  s_position = 0;
  s_last_delta = 0;
  s_prev_cnt = (int16_t)__HAL_TIM_GET_COUNTER(&htim2);
  stall_reset();
}

int16_t MOTOR_GetSpeed(void)        { return s_target; }
int16_t MOTOR_GetAppliedSpeed(void) { return s_applied; }
uint8_t MOTOR_IsFault(void)         { return s_fault; }
void    MOTOR_ClearFault(void)      { s_fault = 0; stall_reset(); }

int16_t MOTOR_GetRPM(void)
{

  int32_t ppr_total = (int32_t)MOTOR_ENC_PPR * MOTOR_GEAR_RATIO * 4;
  if (ppr_total == 0) return 0;
  int32_t counts_per_sec = (int32_t)s_last_delta * 20;
  return (int16_t)((counts_per_sec * 60) / ppr_total);
}

float MOTOR_GetAngleDeg(void)
{
  int32_t ppr_total = (int32_t)MOTOR_ENC_PPR * MOTOR_GEAR_RATIO * 4;
  if (ppr_total == 0) return 0.0f;
  return (float)s_position / (float)ppr_total * 360.0f;
}

float MOTOR_GetArmAngleDeg(void)
{

  return MOTOR_GetAngleDeg() * ARM_DRIVE_RATIO;
}

int16_t MOTOR_GetArmRPM(void)
{

  return (int16_t)((float)MOTOR_GetRPM() * ARM_DRIVE_RATIO);
}

uint8_t MOTOR_AtLimit(void)
{

  float a = MOTOR_GetArmAngleDeg();
  if (a >=  ARM_LIMIT_DEG) return 1;
  if (a <= -ARM_LIMIT_DEG) return 2;
  return 0;
}
