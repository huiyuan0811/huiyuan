#include "ps2.h"
#include "main.h"

// 前两字节是命令，后面填 0 用来读出数据
static const uint8_t PS2_cmnd[9] = {0x01, 0x42, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static uint8_t PS2_data[9] = {0};

static void DWT_DelayInit(void) {
  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CYCCNT = 0;
  DWT->CTRL  |= DWT_CTRL_CYCCNTENA_Msk;
}
static void delay_us(uint32_t us) {
  uint32_t start  = DWT->CYCCNT;
  uint32_t cycles = us * (HAL_RCC_GetHCLKFreq() / 1000000U);
  while ((DWT->CYCCNT - start) < cycles) { }
}

static uint8_t PS2_ReadWriteByte(uint8_t cmd) {
  uint8_t res = 0;
  for (uint8_t ref = 0x01; ref != 0x00; ref <<= 1) {

    HAL_GPIO_WritePin(PS2_CMD_PORT, PS2_CMD_PIN,
                      (cmd & ref) ? GPIO_PIN_SET : GPIO_PIN_RESET);

    HAL_GPIO_WritePin(PS2_CLK_PORT, PS2_CLK_PIN, GPIO_PIN_RESET);
    delay_us(16);

    if (HAL_GPIO_ReadPin(PS2_DI_PORT, PS2_DI_PIN) == GPIO_PIN_SET)
      res |= ref;

    HAL_GPIO_WritePin(PS2_CLK_PORT, PS2_CLK_PIN, GPIO_PIN_SET);
    delay_us(16);
  }
  return res;
}

// CLK 要先拉高，否则首字节会丢失
void PS2_Init(void) {
  DWT_DelayInit();
  HAL_GPIO_WritePin(PS2_CS_PORT,  PS2_CS_PIN,  GPIO_PIN_SET);

  HAL_GPIO_WritePin(PS2_CLK_PORT, PS2_CLK_PIN, GPIO_PIN_SET);
}

void PS2_ScanKey(JOYSTICK_TypeDef *js) {
  HAL_GPIO_WritePin(PS2_CS_PORT, PS2_CS_PIN, GPIO_PIN_RESET);
  for (uint8_t i = 0; i < 9; i++)
    PS2_data[i] = PS2_ReadWriteByte(PS2_cmnd[i]);
  HAL_GPIO_WritePin(PS2_CS_PORT, PS2_CS_PIN, GPIO_PIN_SET);

  js->mode    = PS2_data[1];
  // 按键低电平有效，需要取反
  js->btn1    = (uint8_t)(~PS2_data[3]);
  js->btn2    = (uint8_t)(~PS2_data[4]);
  js->RJoy_LR = PS2_data[5];
  js->RJoy_UD = PS2_data[6];
  js->LJoy_LR = PS2_data[7];
  js->LJoy_UD = PS2_data[8];
}

static void PS2_SendCmd(const uint8_t *cmd, uint8_t len) {
  HAL_GPIO_WritePin(PS2_CS_PORT, PS2_CS_PIN, GPIO_PIN_RESET);
  for (uint8_t i = 0; i < 9; i++) {
    uint8_t b = (i < len) ? cmd[i] : 0x00;
    PS2_ReadWriteByte(b);
  }
  HAL_GPIO_WritePin(PS2_CS_PORT, PS2_CS_PIN, GPIO_PIN_SET);
  HAL_Delay(1);
}

void PS2_SetAnalogMode(void) {
  static const uint8_t enter_cfg[]  = {0x01, 0x43, 0x00, 0x01, 0x00};
  static const uint8_t set_analog[] = {0x01, 0x44, 0x00, 0x01, 0x03, 0x00, 0x00, 0x00, 0x00};
  static const uint8_t exit_cfg[]   = {0x01, 0x43, 0x00, 0x00, 0x5A, 0x5A, 0x5A, 0x5A, 0x5A};
  PS2_SendCmd(enter_cfg,  sizeof(enter_cfg));
  PS2_SendCmd(set_analog, sizeof(set_analog));
  PS2_SendCmd(exit_cfg,   sizeof(exit_cfg));
}
