#include <stdio.h>
#include "main.h"

extern UART_HandleTypeDef huart1;

// printf 从串口输出，调试信息看这里
int __io_putchar(int ch) {
  HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xFFFF);
  return ch;
}
