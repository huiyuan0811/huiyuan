/**
  ******************************************************************************
  * @file    servo.c
  * @brief   MG996R 舵机驱动实现（TIM4 四路 50Hz PWM + 安全限位 + 缓动）
  ******************************************************************************
  */
#include "servo.h"

static const uint32_t servo_ch[4] =
{
  TIM_CHANNEL_1,
  TIM_CHANNEL_2,
  TIM_CHANNEL_3,
  TIM_CHANNEL_4
};

static float servo_cur[4] =
{
  SERVO_SAFE_ANGLE, SERVO_SAFE_ANGLE, SERVO_SAFE_ANGLE, SERVO_SAFE_ANGLE
};
static float servo_tgt[4] =
{
  SERVO_SAFE_ANGLE, SERVO_SAFE_ANGLE, SERVO_SAFE_ANGLE, SERVO_SAFE_ANGLE
};

/**
  * @brief  角度(度) -> TIM4 比较值(CCR)。
  *         TIM4 时钟 = 72MHz / (71+1) = 1MHz，1 个计数 = 1µs。
  *         MG996R：0.5ms(500µs)=0°、2.5ms(2500µs)=180°，线性映射。
  */
static uint32_t angle_to_ccr(float deg)
{
  // 0.5ms 到 2.5ms 对应 0 到 180 度
  float us = 500.0f + (deg / 180.0f) * 2000.0f;
  return (uint32_t)(us + 0.5f);
}

/**
  * @brief  硬限位：把角度夹在 [SERVO_MIN_ANGLE, SERVO_MAX_ANGLE]，绝不允许越界。
  */
// 角度要限幅，到极限位置舵机会堵转
static float clamp_angle(float a)
{
  if (a < SERVO_MIN_ANGLE) a = SERVO_MIN_ANGLE;
  if (a > SERVO_MAX_ANGLE) a = SERVO_MAX_ANGLE;
  return a;
}

void SERVO_Init(void)
{
  for (uint8_t i = 0; i < 4; i++)
  {

    __HAL_TIM_SET_COMPARE(&htim4, servo_ch[i], angle_to_ccr(SERVO_SAFE_ANGLE));
    HAL_TIM_PWM_Start(&htim4, servo_ch[i]);
    servo_cur[i] = SERVO_SAFE_ANGLE;
    servo_tgt[i] = SERVO_SAFE_ANGLE;
  }
}

void SERVO_WriteAngle(uint8_t ch, float angle)
{
  if (ch >= 4) return;
  angle = clamp_angle(angle);
  servo_cur[ch] = angle;
  servo_tgt[ch] = angle;
  __HAL_TIM_SET_COMPARE(&htim4, servo_ch[ch], angle_to_ccr(angle));
}

void SERVO_SetTarget(uint8_t ch, float angle)
{
  if (ch >= 4) return;
  servo_tgt[ch] = clamp_angle(angle);
}

void SERVO_Update(void)
{
  for (uint8_t i = 0; i < 4; i++)
  {
    if (servo_cur[i] < servo_tgt[i])
    {
      servo_cur[i] += SERVO_RAMP_STEP;
      if (servo_cur[i] > servo_tgt[i]) servo_cur[i] = servo_tgt[i];
    }
    else if (servo_cur[i] > servo_tgt[i])
    {
      servo_cur[i] -= SERVO_RAMP_STEP;
      if (servo_cur[i] < servo_tgt[i]) servo_cur[i] = servo_tgt[i];
    }
    __HAL_TIM_SET_COMPARE(&htim4, servo_ch[i], angle_to_ccr(servo_cur[i]));
  }
}

void SERVO_Rotate(uint8_t ch, float delta_deg)
{
  if (ch >= 4) return;

  float a = clamp_angle(servo_cur[ch] + delta_deg);
  servo_cur[ch] = a;
  servo_tgt[ch] = a;
  __HAL_TIM_SET_COMPARE(&htim4, servo_ch[ch], angle_to_ccr(a));
}

float SERVO_GetAngle(uint8_t ch)
{
  if (ch >= 4) return SERVO_SAFE_ANGLE;
  return servo_cur[ch];
}
