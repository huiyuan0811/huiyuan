/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    uart_release.c
  * @brief   接底盘 MCU 的串口驱动（底层 USART2）
  *
  *  详见 uart_release.h 的协议说明。本文件只负责按 [0xAA 0x55 LX LY SUM]
  *  的 5 字节帧把左摇杆值发出去；USART2 句柄 huart2 与底层初始化在
  *  usart.c（CubeMX 生成风格）中，本驱动在 MOTOR/SERVO 同样的约定下只做
  *  “运行时发送”，不初始化外设。
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "uart_release.h"
#include "usart.h"

/* USER CODE BEGIN 0 */

// 记录上次发送的值，初值 0xFF 保证开机首帧能发出
static uint8_t s_last_lx = 0xFFU;
static uint8_t s_last_ly = 0xFFU;

/* USER CODE END 0 */

/* USER CODE BEGIN 1 */

static HAL_StatusTypeDef uart_release_tx(uint8_t lx, uint8_t ly, uint32_t timeout_ms)
{
  uint8_t frame[UART_RELEASE_FRAME_LEN];
  frame[0] = UART_RELEASE_HDR0;
  frame[1] = UART_RELEASE_HDR1;
  frame[2] = lx;
  frame[3] = ly;
  // 最后一字节是校验，两端算法要一致
  frame[4] = (uint8_t)((UART_RELEASE_HDR0 + UART_RELEASE_HDR1 + lx + ly) & 0xFFU);

  return HAL_UART_Transmit(&huart2, frame, UART_RELEASE_FRAME_LEN, timeout_ms);
}

/* USER CODE END 1 */

/**
  * @brief  应用初始化：发一帧中立(128,128)让底盘进入安全态。
  * @note   USART2 外设本身由 main.c 调用 MX_USART2_UART_Init() 完成（CubeMX 风格）；
  *         本函数只是“开机先给底盘一个明确的停/中信号”。
  * @retval None
  */
void UART_RELEASE_Init(void)
{
  /* USER CODE BEGIN UART_RELEASE_Init */

  UART_RELEASE_SendNeutral();
  /* USER CODE END UART_RELEASE_Init */
}

/**
  * @brief  发送一帧左摇杆值给底盘 MCU。
  * @param  lx  左摇杆 X 原始值（0..255，128=居中）
  * @param  ly  左摇杆 Y 原始值（0..255，128=居中）
  * @retval HAL 状态；HAL_OK 表示发送成功
  */
HAL_StatusTypeDef UART_RELEASE_SendJoystick(uint8_t lx, uint8_t ly)
{
  /* USER CODE BEGIN UART_RELEASE_SendJoystick */

  return uart_release_tx(lx, ly, 10U);
  /* USER CODE END UART_RELEASE_SendJoystick */
}

/**
  * @brief  发送中立帧(128,128)，用于上电/急停让底盘停住。
  * @retval HAL 状态
  */
HAL_StatusTypeDef UART_RELEASE_SendNeutral(void)
{
  /* USER CODE BEGIN UART_RELEASE_SendNeutral */
  // 开机先发一帧停止，避免底盘上电就动作
  return uart_release_tx(UART_RELEASE_NEUTRAL, UART_RELEASE_NEUTRAL, 10U);
  /* USER CODE END UART_RELEASE_SendNeutral */
}

/* USER CODE BEGIN 2 */

/**
  * @brief  仅在 LX/LY 相对上次实际发出值变化时才发送（省带宽版）。
  * @retval HAL_OK=本次已发送；HAL_BUSY=本次因“未变化”而跳过（不算错误）；
  *         其它=HAL_UART_Transmit 异常状态。
  */
HAL_StatusTypeDef UART_RELEASE_SendJoystickIfChanged(uint8_t lx, uint8_t ly)
{
  // 和上次一样就跳过，减少串口数据量
  if (lx == s_last_lx && ly == s_last_ly)
  {
    return HAL_BUSY;
  }
  HAL_StatusTypeDef st = uart_release_tx(lx, ly, 10U);
  if (st == HAL_OK)
  {
    s_last_lx = lx;
    s_last_ly = ly;
  }
  return st;
}

/* USER CODE END 2 */
