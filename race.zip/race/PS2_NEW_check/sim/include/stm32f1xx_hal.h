#ifndef STM32F1XX_HAL_H_STUB
#define STM32F1XX_HAL_H_STUB

#include <stdint.h>

typedef enum {
  HAL_OK      = 0x00U,
  HAL_ERROR   = 0x01U,
  HAL_BUSY    = 0x02U,
  HAL_TIMEOUT = 0x03U
} HAL_StatusTypeDef;

typedef enum {
  GPIO_PIN_RESET = 0,
  GPIO_PIN_SET   = 1
} GPIO_PinState;

#define GPIO_PIN_0  ((uint16_t)0x0001)
#define GPIO_PIN_1  ((uint16_t)0x0002)
#define GPIO_PIN_2  ((uint16_t)0x0004)
#define GPIO_PIN_3  ((uint16_t)0x0008)
#define GPIO_PIN_4  ((uint16_t)0x0010)
#define GPIO_PIN_5  ((uint16_t)0x0020)
#define GPIO_PIN_6  ((uint16_t)0x0040)
#define GPIO_PIN_7  ((uint16_t)0x0080)
#define GPIO_PIN_8  ((uint16_t)0x0100)
#define GPIO_PIN_9  ((uint16_t)0x0200)
#define GPIO_PIN_10 ((uint16_t)0x0400)
#define GPIO_PIN_11 ((uint16_t)0x0800)
#define GPIO_PIN_12 ((uint16_t)0x1000)
#define GPIO_PIN_13 ((uint16_t)0x2000)
#define GPIO_PIN_14 ((uint16_t)0x4000)
#define GPIO_PIN_15 ((uint16_t)0x8000)

typedef struct { uint32_t dummy; } GPIO_TypeDef;
#define GPIOA ((GPIO_TypeDef *)0x1000)
#define GPIOB ((GPIO_TypeDef *)0x1001)
#define GPIOC ((GPIO_TypeDef *)0x1002)
#define GPIOD ((GPIO_TypeDef *)0x1003)

typedef struct { void *Instance; } TIM_HandleTypeDef;

#define TIM_CHANNEL_1 ((uint32_t)0x00000000U)
#define TIM_CHANNEL_2 ((uint32_t)0x00000004U)
#define TIM_CHANNEL_3 ((uint32_t)0x00000008U)
#define TIM_CHANNEL_4 ((uint32_t)0x0000000CU)

extern uint32_t g_ccr[4];
#define __HAL_TIM_SET_COMPARE(htim, ch, val) do { g_ccr[((ch) >> 2) & 3U] = (uint32_t)(val); } while (0)

typedef struct { volatile uint32_t CTRL; volatile uint32_t CYCCNT; } DWT_Type;
typedef struct { volatile uint32_t DEMCR; } CoreDebug_Type;
extern DWT_Type      g_dwt;
extern CoreDebug_Type g_coredebug;
#define DWT       (&g_dwt)
#define CoreDebug (&g_coredebug)
#define CoreDebug_DEMCR_TRCENA_Msk (1u << 24)
#define DWT_CTRL_CYCCNTENA_Msk    (1u << 0)

HAL_StatusTypeDef HAL_GPIO_WritePin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin, GPIO_PinState PinState);
GPIO_PinState     HAL_GPIO_ReadPin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void              HAL_Delay(uint32_t Delay);
uint32_t          HAL_RCC_GetHCLKFreq(void);
HAL_StatusTypeDef HAL_TIM_PWM_Start(TIM_HandleTypeDef *htim, uint32_t Channel);

#endif
